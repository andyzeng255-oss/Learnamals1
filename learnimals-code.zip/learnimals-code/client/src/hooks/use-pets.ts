import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";

export function usePets() {
  return useQuery({
    queryKey: [api.pets.list.path],
    queryFn: async () => {
      const res = await fetch(api.pets.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch pets");
      return api.pets.list.responses[200].parse(await res.json());
    },
  });
}

export function usePet(id: number) {
  return useQuery({
    queryKey: [api.pets.get.path, id],
    enabled: !!id,
    queryFn: async () => {
      const url = buildUrl(api.pets.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch pet");
      return api.pets.get.responses[200].parse(await res.json());
    },
  });
}

export function useCreatePet() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: any) => {
      const res = await fetch(api.pets.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create pet");
      return api.pets.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.pets.list.path] });
    },
  });
}

export function useUpdatePet() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & any) => {
      const url = buildUrl(api.pets.update.path, { id });
      const res = await fetch(url, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update pet");
      return api.pets.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.pets.list.path] });
    },
  });
}
