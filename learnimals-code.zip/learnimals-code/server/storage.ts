import { db } from "./db";
import { 
  users, students, teachers, classrooms, classroomStudents, 
  pets, accessories, petAccessories, furniture, roomItems, 
  assignments, studentAssignments, classroomFolders
} from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // User Profiles
  getStudent(userId: string): Promise<typeof students.$inferSelect | undefined>;
  getStudentById(id: number): Promise<typeof students.$inferSelect | undefined>;
  getTeacher(userId: string): Promise<typeof teachers.$inferSelect | undefined>;
  createStudent(data: typeof students.$inferInsert): Promise<typeof students.$inferSelect>;
  createTeacher(data: typeof teachers.$inferInsert): Promise<typeof teachers.$inferSelect>;
  updateStudent(id: number, data: Partial<typeof students.$inferInsert>): Promise<typeof students.$inferSelect>;

  // Classrooms
  getClassroomsByTeacher(teacherId: number): Promise<(typeof classrooms.$inferSelect)[]>;
  getClassroomsByStudent(studentId: number): Promise<(typeof classrooms.$inferSelect)[]>;
  createClassroom(data: typeof classrooms.$inferInsert): Promise<typeof classrooms.$inferSelect>;
  getClassroomByCode(code: string): Promise<typeof classrooms.$inferSelect | undefined>;
  addStudentToClassroom(classroomId: number, studentId: number): Promise<void>;
  createFolder(data: typeof classroomFolders.$inferInsert): Promise<typeof classroomFolders.$inferSelect>;
  getFolders(classroomId: number): Promise<(typeof classroomFolders.$inferSelect)[]>;

  // Pets
  getPetsByStudent(studentId: number): Promise<(typeof pets.$inferSelect)[]>;
  getPet(id: number): Promise<typeof pets.$inferSelect | undefined>;
  createPet(data: typeof pets.$inferInsert): Promise<typeof pets.$inferSelect>;
  updatePet(id: number, data: Partial<typeof pets.$inferInsert>): Promise<typeof pets.$inferSelect>;
  getPetAccessories(petId: number): Promise<(typeof petAccessories.$inferSelect & { accessory: typeof accessories.$inferSelect })[]>;
  unlockAccessory(petId: number, accessoryId: number): Promise<void>;
  equipAccessory(petId: number, accessoryId: number, type: string): Promise<void>;

  // Room
  getRoomItems(studentId: number): Promise<(typeof roomItems.$inferSelect)[]>;
  updateRoomItems(studentId: number, items: (typeof roomItems.$inferInsert)[]): Promise<(typeof roomItems.$inferSelect)[]>;

  // Assignments
  getAssignmentsByClassroom(classroomId: number): Promise<(typeof assignments.$inferSelect)[]>;
  getStudentAssignments(studentId: number): Promise<(typeof studentAssignments.$inferSelect)[]>;
  createAssignment(data: typeof assignments.$inferInsert): Promise<typeof assignments.$inferSelect>;
  submitAssignment(studentId: number, assignmentId: number, score: number, petId: number): Promise<typeof studentAssignments.$inferSelect>;
  awardManualXp(studentId: number, petId: number, xp: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getStudent(userId: string) {
    const [res] = await db.select().from(students).where(eq(students.userId, userId));
    return res;
  }
  async getTeacher(userId: string) {
    const [res] = await db.select().from(teachers).where(eq(teachers.userId, userId));
    return res;
  }
  async createStudent(data: typeof students.$inferInsert) {
    const [res] = await db.insert(students).values(data).returning();
    return res;
  }
  async createTeacher(data: typeof teachers.$inferInsert) {
    const [res] = await db.insert(teachers).values(data).returning();
    return res;
  }

  async getStudentById(id: number) {
    const [res] = await db.select().from(students).where(eq(students.id, id));
    return res;
  }

  async updateStudent(id: number, data: Partial<typeof students.$inferInsert>) {
    const [res] = await db.update(students).set(data).where(eq(students.id, id)).returning();
    return res;
  }

  async getClassroomsByTeacher(teacherId: number) {
    return db.select().from(classrooms).where(eq(classrooms.teacherId, teacherId));
  }
  async getClassroomsByStudent(studentId: number) {
    const links = await db.select().from(classroomStudents).where(eq(classroomStudents.studentId, studentId));
    if (links.length === 0) return [];
    
    return db.select({
      id: classrooms.id,
      teacherId: classrooms.teacherId,
      name: classrooms.name,
      code: classrooms.code
    })
    .from(classrooms)
    .innerJoin(classroomStudents, eq(classrooms.id, classroomStudents.classroomId))
    .where(eq(classroomStudents.studentId, studentId));
  }
  async createClassroom(data: typeof classrooms.$inferInsert) {
    const [res] = await db.insert(classrooms).values(data).returning();
    return res;
  }
  async getClassroomByCode(code: string) {
    const [res] = await db.select().from(classrooms).where(eq(classrooms.code, code));
    return res;
  }
  async addStudentToClassroom(classroomId: number, studentId: number) {
    await db.insert(classroomStudents).values({ classroomId, studentId });
  }

  async createFolder(data: typeof classroomFolders.$inferInsert) {
    const [res] = await db.insert(classroomFolders).values(data).returning();
    return res;
  }

  async getFolders(classroomId: number) {
    return db.select().from(classroomFolders).where(eq(classroomFolders.classroomId, classroomId));
  }

  async getPetsByStudent(studentId: number) {
    return db.select().from(pets).where(eq(pets.studentId, studentId));
  }
  async getPet(id: number) {
    const [res] = await db.select().from(pets).where(eq(pets.id, id));
    return res;
  }
  async createPet(data: typeof pets.$inferInsert) {
    const [res] = await db.insert(pets).values(data).returning();
    return res;
  }
  async updatePet(id: number, data: Partial<typeof pets.$inferInsert>) {
    const [res] = await db.update(pets).set(data).where(eq(pets.id, id)).returning();
    return res;
  }

  async getPetAccessories(petId: number) {
    return db.select({
      id: petAccessories.id,
      petId: petAccessories.petId,
      accessoryId: petAccessories.accessoryId,
      isEquipped: petAccessories.isEquipped,
      unlockedAt: petAccessories.unlockedAt,
      accessory: accessories,
    })
    .from(petAccessories)
    .innerJoin(accessories, eq(petAccessories.accessoryId, accessories.id))
    .where(eq(petAccessories.petId, petId));
  }

  async unlockAccessory(petId: number, accessoryId: number) {
    await db.insert(petAccessories).values({ petId, accessoryId, isEquipped: false }).onConflictDoNothing();
  }

  async equipAccessory(petId: number, accessoryId: number, type: string) {
    await db.transaction(async (tx) => {
      const current = await tx.select({ id: petAccessories.id })
        .from(petAccessories)
        .innerJoin(accessories, eq(petAccessories.accessoryId, accessories.id))
        .where(and(eq(petAccessories.petId, petId), eq(accessories.type, type)));
      
      if (current.length > 0) {
        await tx.update(petAccessories).set({ isEquipped: false }).where(eq(petAccessories.petId, petId));
      }
      
      await tx.update(petAccessories).set({ isEquipped: true }).where(and(eq(petAccessories.petId, petId), eq(petAccessories.accessoryId, accessoryId)));
      
      const pet = (await tx.select().from(pets).where(eq(pets.id, petId)))[0];
      const active = (pet.activeAccessories as any) || {};
      active[type] = accessoryId;
      await tx.update(pets).set({ activeAccessories: active }).where(eq(pets.id, petId));
    });
  }

  async getRoomItems(studentId: number) {
    return db.select().from(roomItems).where(eq(roomItems.studentId, studentId));
  }
  async updateRoomItems(studentId: number, items: (typeof roomItems.$inferInsert)[]) {
    await db.delete(roomItems).where(eq(roomItems.studentId, studentId));
    if (items.length > 0) {
      return db.insert(roomItems).values(items).returning();
    }
    return [];
  }

  async getAssignmentsByClassroom(classroomId: number) {
    return db.select().from(assignments).where(eq(assignments.classroomId, classroomId));
  }
  async getStudentAssignments(studentId: number) {
    return db.select().from(studentAssignments).where(eq(studentAssignments.studentId, studentId));
  }
  async createAssignment(data: typeof assignments.$inferInsert) {
    const [res] = await db.insert(assignments).values(data).returning();
    return res;
  }

  async submitAssignment(studentId: number, assignmentId: number, score: number, petId: number) {
    return await db.transaction(async (tx) => {
      const [assignment] = await tx.select().from(assignments).where(eq(assignments.id, assignmentId));
      const xpReward = Math.floor((score / assignment.maxPoints) * assignment.xpReward);

      const [res] = await tx.insert(studentAssignments).values({
        studentId,
        assignmentId,
        score,
        status: "completed",
        awardedXp: xpReward,
        completedAt: new Date(),
      }).returning();

      const [pet] = await tx.select().from(pets).where(eq(pets.id, petId));
      const newXp = pet.xp + xpReward;
      const newLevel = Math.floor(newXp / 100) + 1; // Simple level logic
      
      await tx.update(pets).set({ 
        xp: newXp, 
        level: newLevel,
        evolutionStage: newLevel >= 5 ? 2 : 1
      }).where(eq(pets.id, petId));

      return res;
    });
  }

  async awardManualXp(studentId: number, petId: number, xp: number) {
    const [pet] = await db.select().from(pets).where(eq(pets.id, petId));
    const newXp = pet.xp + xp;
    const newLevel = Math.floor(newXp / 100) + 1;
    await db.update(pets).set({ 
      xp: newXp, 
      level: newLevel,
      evolutionStage: newLevel >= 5 ? 2 : 1
    }).where(eq(pets.id, petId));
  }
}

export const storage = new DatabaseStorage();
