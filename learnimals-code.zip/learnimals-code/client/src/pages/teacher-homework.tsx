import { useState } from "react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card-custom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { FileText, Upload, Loader2, Sparkles, BookOpen, CheckCircle } from "lucide-react";

interface GeneratedQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
}

interface Homework {
  id: number;
  title: string;
  classroomId: number;
  gradeLevel: number;
  questions: GeneratedQuestion[];
  createdAt: string;
}

export default function TeacherHomework() {
  const { toast } = useToast();
  const [pdfText, setPdfText] = useState("");
  const [title, setTitle] = useState("");
  const [gradeLevel, setGradeLevel] = useState("5");
  const [selectedClassroom, setSelectedClassroom] = useState("");
  const [generatedQuestions, setGeneratedQuestions] = useState<GeneratedQuestion[]>([]);

  const { data: classrooms = [] } = useQuery<any[]>({
    queryKey: ['/api/classrooms'],
  });

  const generateQuestionsMutation = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest("POST", "/api/homework/generate", {
        content,
        gradeLevel: parseInt(gradeLevel),
        numQuestions: 5
      });
      return res.json();
    },
    onSuccess: (data) => {
      setGeneratedQuestions(data.questions);
      toast({
        title: "Questions Generated",
        description: `Generated ${data.questions.length} questions from your content.`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate questions. Please try again.",
        variant: "destructive",
      });
    }
  });

  const saveHomeworkMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/homework", {
        title,
        classroomId: parseInt(selectedClassroom),
        gradeLevel: parseInt(gradeLevel),
        questions: generatedQuestions,
        content: pdfText
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Homework Saved",
        description: "Homework has been assigned to the classroom.",
      });
      setTitle("");
      setPdfText("");
      setGeneratedQuestions([]);
      queryClient.invalidateQueries({ queryKey: ['/api/assignments'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save homework.",
        variant: "destructive",
      });
    }
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type === 'application/pdf') {
      const formData = new FormData();
      formData.append('file', file);
      
      try {
        const res = await fetch('/api/homework/parse-pdf', {
          method: 'POST',
          body: formData,
          credentials: 'include'
        });
        const data = await res.json();
        setPdfText(data.text || "");
        toast({
          title: "PDF Uploaded",
          description: "Text extracted from PDF. You can edit it below.",
        });
      } catch (err) {
        toast({
          title: "Error",
          description: "Failed to parse PDF. Please paste the text manually.",
          variant: "destructive",
        });
      }
    } else if (file.type === 'text/plain') {
      const text = await file.text();
      setPdfText(text);
      toast({
        title: "File Uploaded",
        description: "Text loaded from file.",
      });
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-1">Homework Creator</h1>
          <p className="text-muted-foreground">Upload homework content and generate AI-powered questions</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-primary" />
                Upload Content
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Homework Title</Label>
                <Input 
                  value={title} 
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Chapter 5 Review"
                  data-testid="input-homework-title"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Classroom</Label>
                  <Select value={selectedClassroom} onValueChange={setSelectedClassroom}>
                    <SelectTrigger data-testid="select-classroom">
                      <SelectValue placeholder="Select classroom" />
                    </SelectTrigger>
                    <SelectContent>
                      {classrooms.map((cls: any) => (
                        <SelectItem key={cls.id} value={String(cls.id)}>{cls.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Grade Level</Label>
                  <Select value={gradeLevel} onValueChange={setGradeLevel}>
                    <SelectTrigger data-testid="select-grade">
                      <SelectValue placeholder="Grade" />
                    </SelectTrigger>
                    <SelectContent>
                      {[1,2,3,4,5,6,7,8,9,10,11,12].map(g => (
                        <SelectItem key={g} value={String(g)}>Grade {g}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Upload PDF or Text File</Label>
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center hover:border-primary/50 transition-colors">
                  <input
                    type="file"
                    accept=".pdf,.txt"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="file-upload"
                    data-testid="input-file-upload"
                  />
                  <label htmlFor="file-upload" className="cursor-pointer">
                    <FileText className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">Click to upload PDF or TXT file</p>
                    <p className="text-xs text-muted-foreground mt-1">Or paste content below</p>
                  </label>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Homework Content</Label>
                <Textarea
                  value={pdfText}
                  onChange={(e) => setPdfText(e.target.value)}
                  placeholder="Paste or type the homework content here..."
                  className="min-h-[200px]"
                  data-testid="textarea-content"
                />
              </div>

              <Button 
                onClick={() => generateQuestionsMutation.mutate(pdfText)}
                disabled={!pdfText.trim() || generateQuestionsMutation.isPending}
                className="w-full"
                data-testid="button-generate"
              >
                {generateQuestionsMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating Questions...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Questions with AI
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-primary" />
                Generated Questions
                {generatedQuestions.length > 0 && (
                  <span className="ml-auto text-sm font-normal text-muted-foreground">
                    {generatedQuestions.length} questions
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {generatedQuestions.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No questions generated yet.</p>
                  <p className="text-sm">Upload content and click "Generate Questions"</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {generatedQuestions.map((q, idx) => (
                    <div key={idx} className="p-4 border rounded-lg bg-muted/30">
                      <p className="font-medium mb-2">
                        <span className="text-primary mr-2">Q{idx + 1}.</span>
                        {q.question}
                      </p>
                      <div className="space-y-1 ml-6">
                        {q.options.map((opt, optIdx) => (
                          <div 
                            key={optIdx} 
                            className={`text-sm flex items-center gap-2 ${opt === q.correctAnswer ? 'text-green-600 font-medium' : 'text-muted-foreground'}`}
                          >
                            {opt === q.correctAnswer && <CheckCircle className="w-4 h-4" />}
                            <span>{String.fromCharCode(65 + optIdx)}. {opt}</span>
                          </div>
                        ))}
                      </div>
                      <p className="text-xs text-muted-foreground mt-2 italic">
                        {q.explanation}
                      </p>
                    </div>
                  ))}

                  <Button 
                    onClick={() => saveHomeworkMutation.mutate()}
                    disabled={!title || !selectedClassroom || saveHomeworkMutation.isPending}
                    className="w-full mt-4"
                    data-testid="button-save-homework"
                  >
                    {saveHomeworkMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Save & Assign Homework
                      </>
                    )}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
