import { z } from 'zod';
import { 
  insertStudentSchema, insertTeacherSchema, insertClassroomSchema, 
  insertPetSchema, insertAssignmentSchema, insertRoomItemSchema,
  students, teachers, classrooms, pets, accessories, furniture, roomItems, assignments, studentAssignments
} from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  // === USERS (Students/Teachers) ===
  profile: {
    get: {
      method: 'GET' as const,
      path: '/api/profile',
      responses: {
        200: z.object({
          type: z.enum(['student', 'teacher', 'none']),
          data: z.union([z.any(), z.null()]), // Student or Teacher data
        }),
      },
    },
    createStudent: {
      method: 'POST' as const,
      path: '/api/profile/student',
      input: insertStudentSchema.omit({ userId: true, coins: true, xp: true }),
      responses: {
        201: z.custom<typeof students.$inferSelect>(),
      },
    },
    createTeacher: {
      method: 'POST' as const,
      path: '/api/profile/teacher',
      input: insertTeacherSchema.omit({ userId: true }),
      responses: {
        201: z.custom<typeof teachers.$inferSelect>(),
      },
    },
    updateStudent: {
      method: 'PATCH' as const,
      path: '/api/profile/student',
      input: z.object({ gradeLevel: z.number().optional() }),
      responses: {
        200: z.custom<typeof students.$inferSelect>(),
      },
    },
  },

  // === CLASSROOMS ===
  classrooms: {
    list: {
      method: 'GET' as const,
      path: '/api/classrooms',
      responses: {
        200: z.array(z.custom<typeof classrooms.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/classrooms',
      input: insertClassroomSchema.omit({ teacherId: true }),
      responses: {
        201: z.custom<typeof classrooms.$inferSelect>(),
      },
    },
    join: {
      method: 'POST' as const,
      path: '/api/classrooms/join',
      input: z.object({ code: z.string() }),
      responses: {
        200: z.object({ success: z.boolean() }),
        404: errorSchemas.notFound,
      },
    },
  },

  // === PETS ===
  pets: {
    list: {
      method: 'GET' as const,
      path: '/api/pets',
      responses: {
        200: z.array(z.custom<typeof pets.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/pets',
      input: insertPetSchema.omit({ studentId: true }),
      responses: {
        201: z.custom<typeof pets.$inferSelect>(),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/pets/:id',
      responses: {
        200: z.custom<typeof pets.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    update: {
      method: 'PATCH' as const,
      path: '/api/pets/:id',
      input: insertPetSchema.partial(),
      responses: {
        200: z.custom<typeof pets.$inferSelect>(),
      },
    },
  },

  // === INVENTORY & ROOM ===
  inventory: {
    list: {
      method: 'GET' as const,
      path: '/api/inventory',
      responses: {
        200: z.object({
          accessories: z.array(z.custom<typeof accessories.$inferSelect>()),
          furniture: z.array(z.custom<typeof furniture.$inferSelect>()),
        }),
      },
    },
  },
  room: {
    items: {
      method: 'GET' as const,
      path: '/api/room/items',
      responses: {
        200: z.array(z.custom<typeof roomItems.$inferSelect>()),
      },
    },
    update: {
      method: 'POST' as const,
      path: '/api/room/items',
      input: z.object({
        items: z.array(insertRoomItemSchema.omit({ studentId: true }).extend({ id: z.number().optional() })),
      }),
      responses: {
        200: z.array(z.custom<typeof roomItems.$inferSelect>()),
      },
    },
  },

  // === ASSIGNMENTS ===
  assignments: {
    list: {
      method: 'GET' as const,
      path: '/api/assignments',
      responses: {
        200: z.array(z.custom<typeof assignments.$inferSelect & { status?: string, score?: number }>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/assignments',
      input: insertAssignmentSchema.omit({ classroomId: true }).extend({ classroomId: z.number() }),
      responses: {
        201: z.custom<typeof assignments.$inferSelect>(),
      },
    },
    submit: {
      method: 'POST' as const,
      path: '/api/assignments/:id/submit',
      input: z.object({ score: z.number(), content: z.any() }),
      responses: {
        200: z.custom<typeof studentAssignments.$inferSelect>(),
      },
    },
  },
  // === AI QUESTIONS ===
  ai: {
    generate: {
      method: 'POST' as const,
      path: '/api/ai/generate',
      input: z.object({ subject: z.string(), gradeLevel: z.number(), topic: z.string().optional() }),
      responses: {
        200: z.object({ question: z.string(), options: z.array(z.string()), correctAnswer: z.string(), explanation: z.string() }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
