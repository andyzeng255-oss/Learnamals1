import { Layout } from "@/components/layout";
import { useClassrooms, useCreateClassroom } from "@/hooks/use-classrooms";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card-custom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Users, BookOpen, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function TeacherDashboard() {
  const { data: classrooms } = useClassrooms();
  const createClassroom = useCreateClassroom();
  const [name, setName] = useState("");
  const [open, setOpen] = useState(false);
  const { toast } = useToast();

  const handleCreate = async () => {
    const code = Math.random().toString(36).substring(7).toUpperCase();
    await createClassroom.mutateAsync({ name, code });
    setOpen(false);
    setName("");
    toast({
      title: "Classroom Created",
      description: `Class code: ${code}`,
    });
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast({ title: "Copied!", description: "Class code copied to clipboard." });
  };

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-1">Teacher Dashboard</h1>
            <p className="text-gray-500">Manage your classes and assignments.</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="rounded-full px-6 bg-primary font-bold">
                <Plus className="w-4 h-4 mr-2" /> Create Classroom
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Classroom</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Classroom Name</label>
                  <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Math 101" />
                </div>
                <Button onClick={handleCreate} className="w-full" disabled={createClassroom.isPending}>
                  {createClassroom.isPending ? "Creating..." : "Create Classroom"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {classrooms?.map((cls) => (
            <Card key={cls.id} className="hover-lift relative overflow-hidden">
              <div className="absolute top-0 left-0 w-2 h-full bg-primary" />
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold font-display text-gray-900">{cls.name}</h3>
                    <p className="text-sm text-gray-500 flex items-center gap-1 mt-1 cursor-pointer hover:text-primary" onClick={() => copyCode(cls.code)}>
                      Code: <span className="font-mono font-bold">{cls.code}</span> <Copy className="w-3 h-3" />
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                    <BookOpen className="w-5 h-5" />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="text-center p-3 bg-gray-50 rounded-xl">
                    <div className="text-2xl font-bold text-gray-900">12</div>
                    <div className="text-xs text-gray-500 font-medium uppercase tracking-wide">Students</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-xl">
                    <div className="text-2xl font-bold text-gray-900">5</div>
                    <div className="text-xs text-gray-500 font-medium uppercase tracking-wide">Assignments</div>
                  </div>
                </div>
                
                <div className="flex gap-2 mt-6">
                  <Button variant="outline" className="flex-1">View Class</Button>
                  <Button className="flex-1 bg-primary hover:bg-primary/90">Add Assignment</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}
