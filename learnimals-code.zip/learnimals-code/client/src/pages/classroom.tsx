import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card-custom";
import { useClassrooms, useJoinClassroom } from "@/hooks/use-classrooms";
import { useAssignments } from "@/hooks/use-assignments";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { GraduationCap, ArrowRight, CheckCircle2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Classroom() {
  const { data: classrooms } = useClassrooms();
  const { data: assignments } = useAssignments();
  const joinClassroom = useJoinClassroom();
  const [code, setCode] = useState("");

  const handleJoin = async () => {
    if (!code) return;
    try {
      await joinClassroom.mutateAsync(code);
      setCode("");
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-1">My Classrooms</h1>
            <p className="text-gray-500">Manage your assignments and track your progress.</p>
          </div>
        </div>

        {/* Join Classroom Section */}
        <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-none shadow-xl">
          <CardContent className="flex flex-col md:flex-row items-center justify-between p-8 gap-6">
            <div>
              <h2 className="text-2xl font-bold font-display mb-2">Join a New Class</h2>
              <p className="text-blue-100 max-w-md">Enter the code provided by your teacher to join a new classroom and start receiving assignments.</p>
            </div>
            <div className="flex w-full md:w-auto gap-2">
              <Input 
                value={code} 
                onChange={(e) => setCode(e.target.value)}
                placeholder="Enter class code" 
                className="bg-white/10 border-white/20 text-white placeholder:text-blue-200 min-w-[200px]"
              />
              <Button 
                onClick={handleJoin} 
                disabled={joinClassroom.isPending}
                className="bg-white text-blue-600 hover:bg-blue-50 font-bold"
              >
                Join
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <h2 className="text-xl font-bold font-display text-gray-900 flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-primary" />
              My Classes
            </h2>
            {classrooms?.length ? (
              <div className="grid gap-4">
                {classrooms.map((cls) => (
                  <Card key={cls.id} className="hover-lift cursor-pointer hover:border-primary/30">
                    <CardContent className="p-4 flex items-center justify-between">
                      <div>
                        <h3 className="font-bold text-lg text-gray-900">{cls.name}</h3>
                        <p className="text-sm text-gray-500">Teacher: {cls.teacher?.name || 'Mr. Smith'}</p>
                      </div>
                      <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                        Active
                      </Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                <p className="text-gray-500">You haven't joined any classes yet.</p>
              </div>
            )}
          </div>

          <div className="space-y-6">
            <h2 className="text-xl font-bold font-display text-gray-900 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              Assignments
            </h2>
            {assignments?.length ? (
              <div className="grid gap-4">
                {assignments.map((assignment) => (
                  <Card key={assignment.id} className="hover-lift cursor-pointer">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-bold text-gray-900">{assignment.title}</h3>
                        <Badge variant={assignment.status === 'completed' ? 'default' : 'outline'}>
                          {assignment.status || 'Pending'}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-500 line-clamp-2 mb-4">
                        {assignment.description || 'No description provided.'}
                      </p>
                      <Button size="sm" className="w-full" variant="secondary">
                        {assignment.status === 'completed' ? 'View Results' : 'Start Assignment'}
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                <p className="text-gray-500">No active assignments.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
