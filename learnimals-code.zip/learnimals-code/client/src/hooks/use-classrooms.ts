import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useClassrooms() {
  return useQuery({
    queryKey: [api.classrooms.list.path],
    queryFn: async () => {
      const res = await fetch(api.classrooms.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch classrooms");
      return api.classrooms.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateClassroom() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: any) => {
      const res = await fetch(api.classrooms.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create classroom");
      return api.classrooms.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.classrooms.list.path] });
    },
  });
}

export function useJoinClassroom() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (code: string) => {
      const res = await fetch(api.classrooms.join.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to join classroom");
      return api.classrooms.join.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.classrooms.list.path] });
    },
  });
}
