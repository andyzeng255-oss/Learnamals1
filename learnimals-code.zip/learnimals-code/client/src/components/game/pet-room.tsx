import { useEffect, useRef, useState } from "react";
import Phaser from "phaser";
import type { pets, roomItems as roomItemsTable } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Heart, Star, Zap, Edit3, Save, PauseCircle, PlayCircle } from "lucide-react";

const TILE_SIZE = 32;
const ROOM_WIDTH = 640;
const ROOM_HEIGHT = 400;

const PET_COLORS: Record<string, number> = {
  fox: 0xff6b35,
  cat: 0x9b9b9b,
  dog: 0xd4a574,
  snake: 0x4ade80,
  horse: 0x8b4513,
};

type Pet = typeof pets.$inferSelect;
type RoomItem = typeof roomItemsTable.$inferSelect;

interface PetRoomProps {
  pet: Pet;
  roomItems: RoomItem[];
  onSaveRoom?: (items: RoomItem[]) => void;
}

export const petDefinitions = [
  { type: "fox", name: "Fox", color: "orange" },
  { type: "cat", name: "Cat", color: "gray" },
  { type: "dog", name: "Dog", color: "golden" },
  { type: "snake", name: "Snake", color: "green" },
  { type: "horse", name: "Horse", color: "brown" },
];

class PetRoomScene extends Phaser.Scene {
  private pet!: Pet;
  private petGraphics!: Phaser.GameObjects.Graphics;
  private gridGraphics!: Phaser.GameObjects.Graphics;
  private petX: number = 320;
  private petY: number = 280;
  private targetX: number = 320;
  private targetY: number = 280;
  private isMoving: boolean = false;
  private moveTimer: number = 0;
  private facingLeft: boolean = false;
  private animTime: number = 0;
  private petSize: number = 40;
  private isEditMode: boolean = false;
  private isIdleMode: boolean = false;
  
  private floorBounds = {
    minX: 80,
    maxX: 560,
    minY: 220,
    maxY: 380
  };

  constructor() {
    super({ key: 'PetRoomScene' });
  }

  init(data: { pet: Pet; editMode?: boolean; idleMode?: boolean }) {
    this.pet = data.pet;
    this.petSize = (36 + (this.pet.evolutionStage - 1) * 10) * 1.5;
    this.isEditMode = data.editMode || false;
    this.isIdleMode = data.idleMode || false;
  }

  setIdleMode(idle: boolean) {
    this.isIdleMode = idle;
    if (idle) {
      this.isMoving = false;
    }
  }

  create() {
    this.drawRoom();
    
    this.gridGraphics = this.add.graphics();
    this.gridGraphics.setDepth(5);
    if (this.isEditMode) {
      this.drawGrid();
    }
    
    this.petGraphics = this.add.graphics();
    this.petGraphics.setDepth(10);
    
    this.petX = (this.floorBounds.minX + this.floorBounds.maxX) / 2;
    this.petY = (this.floorBounds.minY + this.floorBounds.maxY) / 2;
    this.targetX = this.petX;
    this.targetY = this.petY;
    
    this.time.delayedCall(1000, () => this.setNewTarget());
  }

  drawGrid() {
    this.gridGraphics.clear();
    this.gridGraphics.lineStyle(1, 0x000000, 0.15);
    for (let x = 0; x <= ROOM_WIDTH; x += TILE_SIZE) {
      this.gridGraphics.moveTo(x, 200);
      this.gridGraphics.lineTo(x, ROOM_HEIGHT);
    }
    for (let y = 200; y <= ROOM_HEIGHT; y += TILE_SIZE) {
      this.gridGraphics.moveTo(0, y);
      this.gridGraphics.lineTo(ROOM_WIDTH, y);
    }
    this.gridGraphics.strokePath();
  }

  setEditMode(editMode: boolean) {
    this.isEditMode = editMode;
    this.gridGraphics.clear();
    if (editMode) {
      this.drawGrid();
    }
  }

  drawRoom() {
    const graphics = this.add.graphics();
    
    graphics.fillStyle(0x8fbc8f, 1);
    graphics.fillRect(0, 0, ROOM_WIDTH, 200);
    
    graphics.fillStyle(0xc9b896, 1);
    graphics.fillRect(0, 200, ROOM_WIDTH, ROOM_HEIGHT - 200);
    
    for (let x = 0; x < ROOM_WIDTH; x += 60) {
      graphics.fillStyle(x % 120 === 0 ? 0xbfae8a : 0xc9b896, 1);
      graphics.fillRect(x, 200, 60, ROOM_HEIGHT - 200);
    }
    
    graphics.fillStyle(0x6b5344, 1);
    graphics.fillRect(0, 195, ROOM_WIDTH, 8);
    graphics.fillStyle(0x5a4636, 1);
    graphics.fillRect(0, 198, ROOM_WIDTH, 5);
    
    graphics.fillStyle(0x6b5344, 1);
    graphics.fillRect(0, ROOM_HEIGHT - 15, ROOM_WIDTH, 15);
    graphics.fillStyle(0x5a4636, 1);
    graphics.fillRect(0, ROOM_HEIGHT - 12, ROOM_WIDTH, 3);
    
    const windowX = 250;
    const windowY = 40;
    const windowW = 140;
    const windowH = 120;
    
    graphics.fillStyle(0x5a4636, 1);
    graphics.fillRect(windowX - 8, windowY - 8, windowW + 16, windowH + 16);
    
    graphics.fillStyle(0x87CEEB, 1);
    graphics.fillRect(windowX, windowY, windowW, windowH);
    
    graphics.fillStyle(0xFFD700, 1);
    graphics.fillCircle(windowX + windowW - 25, windowY + 25, 18);
    graphics.fillStyle(0xFFF8DC, 0.7);
    graphics.fillCircle(windowX + windowW - 25, windowY + 25, 14);
    
    graphics.fillStyle(0xffffff, 0.85);
    graphics.fillEllipse(windowX + 35, windowY + 35, 25, 12);
    graphics.fillEllipse(windowX + 50, windowY + 32, 18, 9);
    graphics.fillEllipse(windowX + windowW - 50, windowY + 50, 22, 10);
    
    graphics.fillStyle(0x90EE90, 1);
    graphics.fillRect(windowX, windowY + windowH - 30, windowW, 30);
    
    graphics.fillStyle(0x228B22, 1);
    graphics.beginPath();
    graphics.moveTo(windowX + 50, windowY + windowH - 30);
    graphics.lineTo(windowX + 65, windowY + windowH - 70);
    graphics.lineTo(windowX + 80, windowY + windowH - 30);
    graphics.closePath();
    graphics.fillPath();
    graphics.beginPath();
    graphics.moveTo(windowX + 45, windowY + windowH - 30);
    graphics.lineTo(windowX + 65, windowY + windowH - 85);
    graphics.lineTo(windowX + 85, windowY + windowH - 30);
    graphics.closePath();
    graphics.fillPath();
    
    graphics.fillStyle(0x8B4513, 1);
    graphics.fillRect(windowX + 61, windowY + windowH - 30, 8, 12);
    
    graphics.fillStyle(0x5a4636, 1);
    graphics.fillRect(windowX + windowW/2 - 2, windowY, 4, windowH);
    graphics.fillRect(windowX, windowY + windowH/2 - 2, windowW, 4);
    
    graphics.lineStyle(3, 0x4a3628, 1);
    graphics.strokeRect(windowX, windowY, windowW, windowH);
  }

  setNewTarget() {
    this.targetX = Phaser.Math.Between(this.floorBounds.minX + 30, this.floorBounds.maxX - 30);
    this.targetY = Phaser.Math.Between(this.floorBounds.minY + 20, this.floorBounds.maxY - 20);
    this.isMoving = true;
  }

  drawPet() {
    this.petGraphics.clear();
    
    const bounce = this.isMoving ? Math.abs(Math.sin(this.animTime * 0.04)) * 4 : Math.sin(this.animTime * 0.012) * 1.5;
    const breathe = 1 + Math.sin(this.animTime * 0.01) * 0.02;
    const drawX = this.petX;
    const drawY = this.petY - bounce;
    const size = this.petSize * breathe;
    const blink = Math.sin(this.animTime * 0.002) > 0.96 ? 0.1 : 1;

    // Shadow
    this.petGraphics.fillStyle(0x000000, 0.08);
    this.petGraphics.fillEllipse(drawX, this.petY + size * 0.45, size * 0.7, size * 0.12);

    switch (this.pet.type) {
      case 'cat':
        this.drawCat(drawX, drawY, size, blink);
        break;
      case 'dog':
        this.drawDog(drawX, drawY, size, blink);
        break;
      case 'snake':
        this.drawSnake(drawX, drawY, size, blink);
        break;
      case 'horse':
        this.drawHorse(drawX, drawY, size, blink);
        break;
      default:
        this.drawFox(drawX, drawY, size, blink);
    }
  }

  drawFox(drawX: number, drawY: number, size: number, blink: number) {
    const orangeFur = 0xf5a623;
    const darkOrange = 0xe08e1a;
    const whiteColor = 0xffffff;
    const blackColor = 0x1a1a1a;
    const pinkInner = 0xffb5b5;
    const tailWag = Math.sin(this.animTime * 0.02) * 10;

    // Fluffy tail
    const tailX = drawX + size * 0.3;
    const tailY = drawY + size * 0.1;
    this.petGraphics.fillStyle(orangeFur, 1);
    this.petGraphics.fillEllipse(tailX + size * 0.2, tailY - size * 0.1 + tailWag * 0.3, size * 0.25, size * 0.18);
    this.petGraphics.fillEllipse(tailX + size * 0.4, tailY - size * 0.3 + tailWag * 0.6, size * 0.28, size * 0.22);
    this.petGraphics.fillStyle(whiteColor, 1);
    this.petGraphics.fillEllipse(tailX + size * 0.5, tailY - size * 0.4 + tailWag, size * 0.2, size * 0.18);

    // Cute stubby legs
    const legAnim = this.isMoving ? Math.sin(this.animTime * 0.03) * 3 : 0;
    this.petGraphics.fillStyle(darkOrange, 1);
    this.petGraphics.fillEllipse(drawX - size * 0.2, drawY + size * 0.38 + legAnim, size * 0.12, size * 0.15);
    this.petGraphics.fillEllipse(drawX + size * 0.2, drawY + size * 0.38 - legAnim, size * 0.12, size * 0.15);

    // Chubby round body
    this.petGraphics.fillStyle(orangeFur, 1);
    this.petGraphics.fillEllipse(drawX, drawY + size * 0.18, size * 0.55, size * 0.45);
    this.petGraphics.fillStyle(whiteColor, 1);
    this.petGraphics.fillEllipse(drawX, drawY + size * 0.25, size * 0.4, size * 0.35);

    // Head
    const headY = drawY - size * 0.15;
    this.petGraphics.fillStyle(orangeFur, 1);
    this.petGraphics.fillCircle(drawX, headY, size * 0.35);

    // Cute pointy ears
    this.petGraphics.beginPath();
    this.petGraphics.moveTo(drawX - size * 0.38, headY - size * 0.2);
    this.petGraphics.lineTo(drawX - size * 0.28, headY - size * 0.6);
    this.petGraphics.lineTo(drawX - size * 0.12, headY - size * 0.25);
    this.petGraphics.closePath();
    this.petGraphics.fillPath();
    this.petGraphics.beginPath();
    this.petGraphics.moveTo(drawX + size * 0.38, headY - size * 0.2);
    this.petGraphics.lineTo(drawX + size * 0.28, headY - size * 0.6);
    this.petGraphics.lineTo(drawX + size * 0.12, headY - size * 0.25);
    this.petGraphics.closePath();
    this.petGraphics.fillPath();

    // Pink inner ears
    this.petGraphics.fillStyle(pinkInner, 1);
    this.petGraphics.beginPath();
    this.petGraphics.moveTo(drawX - size * 0.32, headY - size * 0.25);
    this.petGraphics.lineTo(drawX - size * 0.27, headY - size * 0.48);
    this.petGraphics.lineTo(drawX - size * 0.17, headY - size * 0.28);
    this.petGraphics.closePath();
    this.petGraphics.fillPath();
    this.petGraphics.beginPath();
    this.petGraphics.moveTo(drawX + size * 0.32, headY - size * 0.25);
    this.petGraphics.lineTo(drawX + size * 0.27, headY - size * 0.48);
    this.petGraphics.lineTo(drawX + size * 0.17, headY - size * 0.28);
    this.petGraphics.closePath();
    this.petGraphics.fillPath();

    // White face marking
    this.petGraphics.fillStyle(whiteColor, 1);
    this.petGraphics.fillEllipse(drawX, headY + size * 0.15, size * 0.3, size * 0.22);

    // Big sparkly eyes
    this.petGraphics.fillStyle(blackColor, 1);
    this.petGraphics.fillCircle(drawX - size * 0.15, headY, size * 0.12 * blink);
    this.petGraphics.fillCircle(drawX + size * 0.15, headY, size * 0.12 * blink);
    if (blink > 0.5) {
      this.petGraphics.fillStyle(whiteColor, 1);
      this.petGraphics.fillCircle(drawX - size * 0.18, headY - size * 0.04, size * 0.05);
      this.petGraphics.fillCircle(drawX + size * 0.12, headY - size * 0.04, size * 0.05);
      this.petGraphics.fillCircle(drawX - size * 0.13, headY + size * 0.02, size * 0.025);
      this.petGraphics.fillCircle(drawX + size * 0.17, headY + size * 0.02, size * 0.025);
    }

    // Cute button nose
    this.petGraphics.fillStyle(blackColor, 1);
    this.petGraphics.fillCircle(drawX, headY + size * 0.18, size * 0.06);

    // Rosy blush cheeks
    this.petGraphics.fillStyle(0xffb5b5, 0.6);
    this.petGraphics.fillEllipse(drawX - size * 0.3, headY + size * 0.1, size * 0.1, size * 0.06);
    this.petGraphics.fillEllipse(drawX + size * 0.3, headY + size * 0.1, size * 0.1, size * 0.06);

    // Cute smile
    this.petGraphics.lineStyle(2, blackColor, 0.8);
    this.petGraphics.beginPath();
    this.petGraphics.arc(drawX, headY + size * 0.22, size * 0.08, 0.2, Math.PI - 0.2);
    this.petGraphics.strokePath();
  }

  drawCat(drawX: number, drawY: number, size: number, blink: number) {
    const grayFur = 0x9ca3af;
    const lightGray = 0xd1d5db;
    const whiteColor = 0xffffff;
    const blackColor = 0x1a1a1a;
    const pinkInner = 0xffb5b5;
    const tailWag = Math.sin(this.animTime * 0.015) * 12;

    // Curly cute tail
    this.petGraphics.fillStyle(grayFur, 1);
    this.petGraphics.fillEllipse(drawX + size * 0.35, drawY + size * 0.05 + tailWag * 0.2, size * 0.1, size * 0.18);
    this.petGraphics.fillEllipse(drawX + size * 0.48, drawY - size * 0.15 + tailWag * 0.5, size * 0.1, size * 0.2);
    this.petGraphics.fillEllipse(drawX + size * 0.55, drawY - size * 0.35 + tailWag, size * 0.12, size * 0.15);

    // Cute stubby legs with white paws
    const legAnim = this.isMoving ? Math.sin(this.animTime * 0.03) * 3 : 0;
    this.petGraphics.fillStyle(grayFur, 1);
    this.petGraphics.fillEllipse(drawX - size * 0.18, drawY + size * 0.38 + legAnim, size * 0.12, size * 0.15);
    this.petGraphics.fillEllipse(drawX + size * 0.18, drawY + size * 0.38 - legAnim, size * 0.12, size * 0.15);
    this.petGraphics.fillStyle(whiteColor, 1);
    this.petGraphics.fillEllipse(drawX - size * 0.18, drawY + size * 0.44, size * 0.1, size * 0.08);
    this.petGraphics.fillEllipse(drawX + size * 0.18, drawY + size * 0.44, size * 0.1, size * 0.08);

    // Chubby round body
    this.petGraphics.fillStyle(grayFur, 1);
    this.petGraphics.fillEllipse(drawX, drawY + size * 0.18, size * 0.52, size * 0.42);
    this.petGraphics.fillStyle(lightGray, 1);
    this.petGraphics.fillEllipse(drawX, drawY + size * 0.24, size * 0.35, size * 0.3);

    // Head
    const headY = drawY - size * 0.15;
    this.petGraphics.fillStyle(grayFur, 1);
    this.petGraphics.fillCircle(drawX, headY, size * 0.35);

    // Cute triangular ears
    this.petGraphics.beginPath();
    this.petGraphics.moveTo(drawX - size * 0.4, headY - size * 0.15);
    this.petGraphics.lineTo(drawX - size * 0.3, headY - size * 0.58);
    this.petGraphics.lineTo(drawX - size * 0.1, headY - size * 0.2);
    this.petGraphics.closePath();
    this.petGraphics.fillPath();
    this.petGraphics.beginPath();
    this.petGraphics.moveTo(drawX + size * 0.4, headY - size * 0.15);
    this.petGraphics.lineTo(drawX + size * 0.3, headY - size * 0.58);
    this.petGraphics.lineTo(drawX + size * 0.1, headY - size * 0.2);
    this.petGraphics.closePath();
    this.petGraphics.fillPath();

    // Pink inner ears
    this.petGraphics.fillStyle(pinkInner, 1);
    this.petGraphics.beginPath();
    this.petGraphics.moveTo(drawX - size * 0.35, headY - size * 0.2);
    this.petGraphics.lineTo(drawX - size * 0.3, headY - size * 0.48);
    this.petGraphics.lineTo(drawX - size * 0.15, headY - size * 0.23);
    this.petGraphics.closePath();
    this.petGraphics.fillPath();
    this.petGraphics.beginPath();
    this.petGraphics.moveTo(drawX + size * 0.35, headY - size * 0.2);
    this.petGraphics.lineTo(drawX + size * 0.3, headY - size * 0.48);
    this.petGraphics.lineTo(drawX + size * 0.15, headY - size * 0.23);
    this.petGraphics.closePath();
    this.petGraphics.fillPath();

    // Big sparkly cat eyes
    this.petGraphics.fillStyle(0x7dd3fc, 1);
    this.petGraphics.fillCircle(drawX - size * 0.15, headY, size * 0.12 * blink);
    this.petGraphics.fillCircle(drawX + size * 0.15, headY, size * 0.12 * blink);
    this.petGraphics.fillStyle(blackColor, 1);
    this.petGraphics.fillEllipse(drawX - size * 0.15, headY, size * 0.04, size * 0.1 * blink);
    this.petGraphics.fillEllipse(drawX + size * 0.15, headY, size * 0.04, size * 0.1 * blink);
    if (blink > 0.5) {
      this.petGraphics.fillStyle(whiteColor, 1);
      this.petGraphics.fillCircle(drawX - size * 0.18, headY - size * 0.04, size * 0.04);
      this.petGraphics.fillCircle(drawX + size * 0.12, headY - size * 0.04, size * 0.04);
    }

    // Cute pink nose
    this.petGraphics.fillStyle(pinkInner, 1);
    this.petGraphics.fillCircle(drawX, headY + size * 0.15, size * 0.06);

    // Rosy blush cheeks
    this.petGraphics.fillStyle(0xffb5b5, 0.6);
    this.petGraphics.fillEllipse(drawX - size * 0.32, headY + size * 0.08, size * 0.1, size * 0.06);
    this.petGraphics.fillEllipse(drawX + size * 0.32, headY + size * 0.08, size * 0.1, size * 0.06);

    // Cute whiskers
    this.petGraphics.lineStyle(1.5, blackColor, 0.4);
    this.petGraphics.beginPath();
    this.petGraphics.moveTo(drawX - size * 0.08, headY + size * 0.18);
    this.petGraphics.lineTo(drawX - size * 0.35, headY + size * 0.12);
    this.petGraphics.moveTo(drawX - size * 0.08, headY + size * 0.22);
    this.petGraphics.lineTo(drawX - size * 0.35, headY + size * 0.24);
    this.petGraphics.moveTo(drawX + size * 0.08, headY + size * 0.18);
    this.petGraphics.lineTo(drawX + size * 0.35, headY + size * 0.12);
    this.petGraphics.moveTo(drawX + size * 0.08, headY + size * 0.22);
    this.petGraphics.lineTo(drawX + size * 0.35, headY + size * 0.24);
    this.petGraphics.strokePath();

    // Cute smile
    this.petGraphics.lineStyle(2, blackColor, 0.8);
    this.petGraphics.beginPath();
    this.petGraphics.arc(drawX, headY + size * 0.22, size * 0.08, 0.2, Math.PI - 0.2);
    this.petGraphics.strokePath();
  }

  drawDog(drawX: number, drawY: number, size: number, blink: number) {
    const brownFur = 0xdeb887;
    const darkBrown = 0xb8860b;
    const whiteColor = 0xffffff;
    const blackColor = 0x1a1a1a;
    const pinkTongue = 0xffb5b5;
    const tailWag = Math.sin(this.animTime * 0.04) * 15;

    // Happy wagging tail
    this.petGraphics.fillStyle(brownFur, 1);
    this.petGraphics.fillEllipse(drawX + size * 0.35 + tailWag * 0.12, drawY - size * 0.05, size * 0.12, size * 0.2);
    this.petGraphics.fillEllipse(drawX + size * 0.42 + tailWag * 0.15, drawY - size * 0.2, size * 0.1, size * 0.15);

    // Cute stubby legs
    const legAnim = this.isMoving ? Math.sin(this.animTime * 0.04) * 3 : 0;
    this.petGraphics.fillStyle(brownFur, 1);
    this.petGraphics.fillEllipse(drawX - size * 0.2, drawY + size * 0.38 + legAnim, size * 0.12, size * 0.15);
    this.petGraphics.fillEllipse(drawX + size * 0.2, drawY + size * 0.38 - legAnim, size * 0.12, size * 0.15);
    this.petGraphics.fillStyle(darkBrown, 1);
    this.petGraphics.fillEllipse(drawX - size * 0.2, drawY + size * 0.44, size * 0.1, size * 0.08);
    this.petGraphics.fillEllipse(drawX + size * 0.2, drawY + size * 0.44, size * 0.1, size * 0.08);

    // Chubby round body
    this.petGraphics.fillStyle(brownFur, 1);
    this.petGraphics.fillEllipse(drawX, drawY + size * 0.18, size * 0.55, size * 0.45);
    this.petGraphics.fillStyle(whiteColor, 1);
    this.petGraphics.fillEllipse(drawX, drawY + size * 0.24, size * 0.38, size * 0.32);

    // Head
    const headY = drawY - size * 0.15;
    this.petGraphics.fillStyle(brownFur, 1);
    this.petGraphics.fillCircle(drawX, headY, size * 0.38);

    // Cute floppy ears
    this.petGraphics.fillStyle(darkBrown, 1);
    this.petGraphics.fillEllipse(drawX - size * 0.42, headY + size * 0.08, size * 0.18, size * 0.35);
    this.petGraphics.fillEllipse(drawX + size * 0.42, headY + size * 0.08, size * 0.18, size * 0.35);

    // White snout area
    this.petGraphics.fillStyle(whiteColor, 1);
    this.petGraphics.fillEllipse(drawX, headY + size * 0.15, size * 0.28, size * 0.22);

    // Big sparkly eyes
    this.petGraphics.fillStyle(blackColor, 1);
    this.petGraphics.fillCircle(drawX - size * 0.15, headY - size * 0.02, size * 0.12 * blink);
    this.petGraphics.fillCircle(drawX + size * 0.15, headY - size * 0.02, size * 0.12 * blink);
    if (blink > 0.5) {
      this.petGraphics.fillStyle(whiteColor, 1);
      this.petGraphics.fillCircle(drawX - size * 0.18, headY - size * 0.06, size * 0.05);
      this.petGraphics.fillCircle(drawX + size * 0.12, headY - size * 0.06, size * 0.05);
      this.petGraphics.fillCircle(drawX - size * 0.13, headY, size * 0.025);
      this.petGraphics.fillCircle(drawX + size * 0.17, headY, size * 0.025);
    }

    // Cute button nose
    this.petGraphics.fillStyle(blackColor, 1);
    this.petGraphics.fillCircle(drawX, headY + size * 0.15, size * 0.08);

    // Rosy blush cheeks
    this.petGraphics.fillStyle(0xffb5b5, 0.6);
    this.petGraphics.fillEllipse(drawX - size * 0.32, headY + size * 0.08, size * 0.1, size * 0.06);
    this.petGraphics.fillEllipse(drawX + size * 0.32, headY + size * 0.08, size * 0.1, size * 0.06);

    // Happy tongue when idle
    if (!this.isMoving) {
      this.petGraphics.fillStyle(pinkTongue, 1);
      this.petGraphics.fillEllipse(drawX, headY + size * 0.32, size * 0.1, size * 0.14);
    }

    // Cute smile
    this.petGraphics.lineStyle(2, blackColor, 0.8);
    this.petGraphics.beginPath();
    this.petGraphics.arc(drawX, headY + size * 0.24, size * 0.1, 0.2, Math.PI - 0.2);
    this.petGraphics.strokePath();
  }

  drawSnake(drawX: number, drawY: number, size: number, blink: number) {
    const greenScale = 0x86efac;
    const darkGreen = 0x4ade80;
    const yellowBelly = 0xfef9c3;
    const whiteColor = 0xffffff;
    const blackColor = 0x1a1a1a;
    const slither = Math.sin(this.animTime * 0.02) * 8;

    // Cute coiled body
    this.petGraphics.fillStyle(greenScale, 1);
    this.petGraphics.fillEllipse(drawX + size * 0.25, drawY + size * 0.25 + slither * 0.3, size * 0.35, size * 0.28);
    this.petGraphics.fillEllipse(drawX - size * 0.08, drawY + size * 0.18 - slither * 0.2, size * 0.4, size * 0.32);
    this.petGraphics.fillEllipse(drawX + size * 0.12, drawY + size * 0.08 + slither * 0.4, size * 0.38, size * 0.28);

    // Cute spots pattern
    this.petGraphics.fillStyle(darkGreen, 1);
    this.petGraphics.fillCircle(drawX + size * 0.32, drawY + size * 0.22, size * 0.1);
    this.petGraphics.fillCircle(drawX - size * 0.12, drawY + size * 0.15, size * 0.12);
    this.petGraphics.fillCircle(drawX + size * 0.18, drawY + size * 0.05, size * 0.1);

    // Light belly
    this.petGraphics.fillStyle(yellowBelly, 1);
    this.petGraphics.fillEllipse(drawX, drawY + size * 0.28, size * 0.18, size * 0.12);

    // Head
    const headY = drawY - size * 0.15 + slither * 0.2;
    this.petGraphics.fillStyle(greenScale, 1);
    this.petGraphics.fillCircle(drawX, headY, size * 0.28);

    // Cute rosy cheeks on head
    this.petGraphics.fillStyle(0xffb5b5, 0.5);
    this.petGraphics.fillEllipse(drawX - size * 0.28, headY + size * 0.08, size * 0.08, size * 0.05);
    this.petGraphics.fillEllipse(drawX + size * 0.28, headY + size * 0.08, size * 0.08, size * 0.05);

    // Big sparkly eyes
    this.petGraphics.fillStyle(whiteColor, 1);
    this.petGraphics.fillCircle(drawX - size * 0.12, headY - size * 0.02, size * 0.12);
    this.petGraphics.fillCircle(drawX + size * 0.12, headY - size * 0.02, size * 0.12);
    this.petGraphics.fillStyle(blackColor, 1);
    this.petGraphics.fillCircle(drawX - size * 0.12, headY - size * 0.02, size * 0.08 * blink);
    this.petGraphics.fillCircle(drawX + size * 0.12, headY - size * 0.02, size * 0.08 * blink);
    if (blink > 0.5) {
      this.petGraphics.fillStyle(whiteColor, 1);
      this.petGraphics.fillCircle(drawX - size * 0.15, headY - size * 0.06, size * 0.04);
      this.petGraphics.fillCircle(drawX + size * 0.09, headY - size * 0.06, size * 0.04);
    }

    // Cute forked tongue
    const tongueOut = Math.sin(this.animTime * 0.01) > 0.6;
    if (tongueOut) {
      this.petGraphics.fillStyle(0xffb5b5, 1);
      this.petGraphics.fillRect(drawX - size * 0.025, headY + size * 0.18, size * 0.05, size * 0.12);
      this.petGraphics.beginPath();
      this.petGraphics.moveTo(drawX - size * 0.025, headY + size * 0.3);
      this.petGraphics.lineTo(drawX - size * 0.08, headY + size * 0.38);
      this.petGraphics.lineTo(drawX, headY + size * 0.32);
      this.petGraphics.lineTo(drawX + size * 0.08, headY + size * 0.38);
      this.petGraphics.lineTo(drawX + size * 0.025, headY + size * 0.3);
      this.petGraphics.closePath();
      this.petGraphics.fillPath();
    }

    // Cute smile
    this.petGraphics.lineStyle(2, blackColor, 0.8);
    this.petGraphics.beginPath();
    this.petGraphics.arc(drawX, headY + size * 0.12, size * 0.08, 0.2, Math.PI - 0.2);
    this.petGraphics.strokePath();
  }

  drawHorse(drawX: number, drawY: number, size: number, blink: number) {
    const brownBody = 0xc9a66b;
    const lightBrown = 0xdec89d;
    const whiteColor = 0xffffff;
    const blackColor = 0x1a1a1a;
    const maneColor = 0x8b6914;

    // Cute fluffy tail
    const tailSway = Math.sin(this.animTime * 0.015) * 6;
    this.petGraphics.fillStyle(maneColor, 1);
    this.petGraphics.fillEllipse(drawX + size * 0.4, drawY + size * 0.05 + tailSway, size * 0.12, size * 0.25);
    this.petGraphics.fillEllipse(drawX + size * 0.48, drawY + size * 0.15 + tailSway * 1.2, size * 0.1, size * 0.2);

    // Cute stubby legs
    const legAnim = this.isMoving ? Math.sin(this.animTime * 0.03) * 3 : 0;
    this.petGraphics.fillStyle(brownBody, 1);
    this.petGraphics.fillEllipse(drawX - size * 0.2, drawY + size * 0.38 + legAnim, size * 0.12, size * 0.15);
    this.petGraphics.fillEllipse(drawX + size * 0.2, drawY + size * 0.38 - legAnim, size * 0.12, size * 0.15);
    // Cute hooves
    this.petGraphics.fillStyle(0x5d4e37, 1);
    this.petGraphics.fillEllipse(drawX - size * 0.2, drawY + size * 0.46, size * 0.1, size * 0.06);
    this.petGraphics.fillEllipse(drawX + size * 0.2, drawY + size * 0.46, size * 0.1, size * 0.06);

    // Chubby round body
    this.petGraphics.fillStyle(brownBody, 1);
    this.petGraphics.fillEllipse(drawX, drawY + size * 0.18, size * 0.58, size * 0.48);
    this.petGraphics.fillStyle(lightBrown, 1);
    this.petGraphics.fillEllipse(drawX, drawY + size * 0.24, size * 0.4, size * 0.35);

    // Head
    const headY = drawY - size * 0.15;
    this.petGraphics.fillStyle(brownBody, 1);
    this.petGraphics.fillCircle(drawX, headY, size * 0.35);

    // Light snout area
    this.petGraphics.fillStyle(lightBrown, 1);
    this.petGraphics.fillEllipse(drawX, headY + size * 0.18, size * 0.25, size * 0.18);

    // Cute fluffy mane
    this.petGraphics.fillStyle(maneColor, 1);
    this.petGraphics.fillEllipse(drawX, headY - size * 0.35, size * 0.2, size * 0.15);
    this.petGraphics.fillEllipse(drawX - size * 0.08, headY - size * 0.4, size * 0.12, size * 0.12);
    this.petGraphics.fillEllipse(drawX + size * 0.1, headY - size * 0.38, size * 0.12, size * 0.1);

    // Cute upright ears
    this.petGraphics.fillStyle(brownBody, 1);
    this.petGraphics.beginPath();
    this.petGraphics.moveTo(drawX - size * 0.32, headY - size * 0.2);
    this.petGraphics.lineTo(drawX - size * 0.28, headY - size * 0.5);
    this.petGraphics.lineTo(drawX - size * 0.18, headY - size * 0.25);
    this.petGraphics.closePath();
    this.petGraphics.fillPath();
    this.petGraphics.beginPath();
    this.petGraphics.moveTo(drawX + size * 0.32, headY - size * 0.2);
    this.petGraphics.lineTo(drawX + size * 0.28, headY - size * 0.5);
    this.petGraphics.lineTo(drawX + size * 0.18, headY - size * 0.25);
    this.petGraphics.closePath();
    this.petGraphics.fillPath();

    // Inner ears
    this.petGraphics.fillStyle(0xffb5b5, 1);
    this.petGraphics.beginPath();
    this.petGraphics.moveTo(drawX - size * 0.28, headY - size * 0.25);
    this.petGraphics.lineTo(drawX - size * 0.27, headY - size * 0.42);
    this.petGraphics.lineTo(drawX - size * 0.2, headY - size * 0.28);
    this.petGraphics.closePath();
    this.petGraphics.fillPath();
    this.petGraphics.beginPath();
    this.petGraphics.moveTo(drawX + size * 0.28, headY - size * 0.25);
    this.petGraphics.lineTo(drawX + size * 0.27, headY - size * 0.42);
    this.petGraphics.lineTo(drawX + size * 0.2, headY - size * 0.28);
    this.petGraphics.closePath();
    this.petGraphics.fillPath();

    // Big sparkly eyes
    this.petGraphics.fillStyle(blackColor, 1);
    this.petGraphics.fillCircle(drawX - size * 0.15, headY, size * 0.12 * blink);
    this.petGraphics.fillCircle(drawX + size * 0.15, headY, size * 0.12 * blink);
    if (blink > 0.5) {
      this.petGraphics.fillStyle(whiteColor, 1);
      this.petGraphics.fillCircle(drawX - size * 0.18, headY - size * 0.04, size * 0.05);
      this.petGraphics.fillCircle(drawX + size * 0.12, headY - size * 0.04, size * 0.05);
      this.petGraphics.fillCircle(drawX - size * 0.13, headY + size * 0.02, size * 0.025);
      this.petGraphics.fillCircle(drawX + size * 0.17, headY + size * 0.02, size * 0.025);
    }

    // Cute nostrils
    this.petGraphics.fillStyle(0x8b6b4d, 1);
    this.petGraphics.fillCircle(drawX - size * 0.08, headY + size * 0.22, size * 0.04);
    this.petGraphics.fillCircle(drawX + size * 0.08, headY + size * 0.22, size * 0.04);

    // Rosy blush cheeks
    this.petGraphics.fillStyle(0xffb5b5, 0.6);
    this.petGraphics.fillEllipse(drawX - size * 0.32, headY + size * 0.08, size * 0.1, size * 0.06);
    this.petGraphics.fillEllipse(drawX + size * 0.32, headY + size * 0.08, size * 0.1, size * 0.06);

    // Cute smile
    this.petGraphics.lineStyle(2, blackColor, 0.8);
    this.petGraphics.beginPath();
    this.petGraphics.arc(drawX, headY + size * 0.28, size * 0.08, 0.2, Math.PI - 0.2);
    this.petGraphics.strokePath();
  }

  update(time: number, delta: number) {
    this.animTime = time;
    
    if (!this.isIdleMode) {
      if (this.isMoving) {
        const speed = 1.5;
        const dx = this.targetX - this.petX;
        const dy = this.targetY - this.petY;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance < 5) {
          this.isMoving = false;
          this.moveTimer = time + Phaser.Math.Between(2000, 4000);
        } else {
          this.petX += (dx / distance) * speed;
          this.petY += (dy / distance) * speed;
          this.facingLeft = dx < 0;
        }
      } else {
        if (time > this.moveTimer) {
          this.setNewTarget();
        }
      }
    }
    
    this.drawPet();
  }
}

interface PetSelectorProps {
  pets: Pet[];
  selectedPetId: number | null;
  onSelect: (petId: number) => void;
  onAdopt: () => void;
}

export function PetSelector({ pets, selectedPetId, onSelect, onAdopt }: PetSelectorProps) {
  return (
    <Card className="p-4">
      <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
        <h3 className="font-bold font-display text-lg">My Pets</h3>
        <Button size="sm" onClick={onAdopt} data-testid="button-adopt-pet">
          <Heart className="w-4 h-4 mr-1" /> Adopt New
        </Button>
      </div>
      
      {pets.length === 0 ? (
        <div className="text-center py-6 text-muted-foreground">
          <p>You don't have any pets yet!</p>
          <p className="text-sm">Click "Adopt New" to get your first pet.</p>
        </div>
      ) : (
        <div className="flex gap-2 flex-wrap">
          {pets.map((pet) => (
            <button
              key={pet.id}
              onClick={() => onSelect(pet.id)}
              className={`p-3 rounded-xl border-2 transition-all ${
                selectedPetId === pet.id 
                  ? 'border-primary bg-primary/10 scale-105' 
                  : 'border-gray-200 hover:border-primary/50'
              }`}
              data-testid={`button-select-pet-${pet.id}`}
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-lg mb-1">
                {pet.name.charAt(0)}
              </div>
              <div className="text-xs font-medium truncate max-w-16">{pet.name}</div>
              <div className="text-xs text-muted-foreground">Lv.{pet.level}</div>
            </button>
          ))}
        </div>
      )}
    </Card>
  );
}

export function PetRoom({ pet, roomItems, onSaveRoom }: PetRoomProps) {
  const gameRef = useRef<Phaser.Game | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isIdle, setIsIdle] = useState(false);

  useEffect(() => {
    if (gameRef.current) {
      gameRef.current.destroy(true);
      gameRef.current = null;
    }

    if (!containerRef.current) return;

    const config: Phaser.Types.Core.GameConfig = {
      type: Phaser.AUTO,
      parent: containerRef.current,
      width: ROOM_WIDTH,
      height: ROOM_HEIGHT,
      backgroundColor: "#1a1a2e",
      scene: PetRoomScene,
    };

    gameRef.current = new Phaser.Game(config);
    gameRef.current.scene.start('PetRoomScene', { pet, editMode: isEditing, idleMode: isIdle });

    return () => {
      gameRef.current?.destroy(true);
      gameRef.current = null;
    };
  }, [pet.id, pet.type]);

  useEffect(() => {
    if (gameRef.current) {
      const scene = gameRef.current.scene.getScene('PetRoomScene') as PetRoomScene;
      if (scene && scene.setEditMode) {
        scene.setEditMode(isEditing);
      }
    }
  }, [isEditing]);

  useEffect(() => {
    if (gameRef.current) {
      const scene = gameRef.current.scene.getScene('PetRoomScene') as PetRoomScene;
      if (scene && scene.setIdleMode) {
        scene.setIdleMode(isIdle);
      }
    }
  }, [isIdle]);

  const xpProgress = (pet.xp % 100);
  const xpToNext = 100;

  return (
    <div className="space-y-4">
      <Card className="overflow-hidden border-4 border-purple-200">
        <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100 py-3 px-4">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-lg shadow-lg">
                {pet.name.charAt(0)}
              </div>
              <div>
                <CardTitle className="text-lg font-display">{pet.name}</CardTitle>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="secondary" className="text-xs">
                    <Star className="w-3 h-3 mr-1" /> Lvl {pet.level}
                  </Badge>
                  <Badge variant="outline" className="text-xs capitalize">
                    {pet.type}
                  </Badge>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant={isIdle ? "default" : "outline"}
                onClick={() => setIsIdle(!isIdle)}
                data-testid="button-idle-pet"
              >
                {isIdle ? <><PlayCircle className="w-4 h-4 mr-1" /> Move</> : <><PauseCircle className="w-4 h-4 mr-1" /> Idle</>}
              </Button>
              <Button
                size="sm"
                variant={isEditing ? "default" : "outline"}
                onClick={() => setIsEditing(!isEditing)}
                data-testid="button-edit-room"
              >
                {isEditing ? <><Save className="w-4 h-4 mr-1" /> Save</> : <><Edit3 className="w-4 h-4 mr-1" /> Edit Room</>}
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="p-0">
          <div 
            ref={containerRef} 
            id="phaser-container"
            className="w-full flex justify-center"
            data-testid="game-pet-room"
          />
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-5 h-5 text-yellow-500" />
            <span className="font-bold text-sm">XP Progress</span>
          </div>
          <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 transition-all duration-500"
              style={{ width: `${(xpProgress / xpToNext) * 100}%` }}
            />
          </div>
          <div className="text-xs text-muted-foreground mt-1">{xpProgress} / {xpToNext} XP</div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5 text-purple-500" />
            <span className="font-bold text-sm">Evolution</span>
          </div>
          <div className="flex gap-1">
            {[1, 2].map((stage) => (
              <div 
                key={stage}
                className={`flex-1 h-3 rounded-full ${pet.evolutionStage >= stage ? 'bg-gradient-to-r from-purple-400 to-pink-500' : 'bg-gray-200'}`}
              />
            ))}
          </div>
          <div className="text-xs text-muted-foreground mt-1">Stage {pet.evolutionStage} of 2</div>
        </Card>
      </div>
    </div>
  );
}
