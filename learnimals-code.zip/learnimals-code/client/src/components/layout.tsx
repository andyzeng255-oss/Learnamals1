import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useProfile } from "@/hooks/use-profile";
import { LayoutDashboard, Gamepad2, GraduationCap, ShoppingBag, UserCircle, LogOut, Backpack, FileText, Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { user, logout } = useAuth();
  const { data: profile } = useProfile();
  
  const isStudent = profile?.type === 'student';

  const navItems = isStudent ? [
    { href: "/dashboard", label: "My Room", icon: LayoutDashboard },
    { href: "/classroom", label: "Classroom", icon: GraduationCap },
    { href: "/dashboard?tab=store", label: "Store", icon: ShoppingBag },
    { href: "/dashboard?tab=inventory", label: "Inventory", icon: Backpack },
    { href: "/dashboard?tab=practice", label: "Practice", icon: Gamepad2 },
  ] : [
    { href: "/teacher-dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/teacher-classrooms", label: "My Classrooms", icon: GraduationCap },
    { href: "/teacher-homework", label: "Homework", icon: FileText },
  ];

  const handleNavClick = (href: string) => {
    // Use window.location for URLs with query params to ensure proper navigation
    if (href.includes('?')) {
      window.history.pushState({}, '', href);
      window.dispatchEvent(new Event('popstate'));
    } else {
      setLocation(href);
    }
  };

  const currentFullPath = typeof window !== 'undefined' ? window.location.pathname + window.location.search : location;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-white border-r border-gray-200 flex flex-col sticky top-0 z-20 h-auto md:h-screen">
        <div className="p-6 border-b border-gray-100 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center text-white font-bold text-xl font-display shadow-lg shadow-primary/20">
            L
          </div>
          <span className="text-xl font-bold font-display text-gray-900 tracking-tight">Learnimals</span>
        </div>

        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = currentFullPath === item.href || 
              (item.href === '/dashboard' && location === '/dashboard' && !window.location.search);
            return (
              <div 
                key={item.href}
                onClick={() => handleNavClick(item.href)}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all duration-200 cursor-pointer",
                  isActive 
                    ? "bg-primary/10 text-primary shadow-sm" 
                    : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                )}
                data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
              >
                <item.icon className={cn("w-5 h-5", isActive && "text-primary")} />
                {item.label}
              </div>
            );
          })}
        </nav>

        <div className="p-4 border-t border-gray-100">
          <div className="flex items-center gap-3 px-4 py-3 mb-2">
            {user?.profileImageUrl ? (
              <img src={user.profileImageUrl} alt="Profile" className="w-10 h-10 rounded-full border-2 border-white shadow-sm" />
            ) : (
              <div className="w-10 h-10 rounded-full bg-secondary/20 flex items-center justify-center text-secondary-foreground">
                <UserCircle className="w-6 h-6" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-gray-900 truncate font-display">
                {user?.firstName || 'User'}
              </p>
              <p className="text-xs text-gray-500 truncate capitalize">{profile?.type || 'Guest'}</p>
            </div>
          </div>

          {isStudent && profile?.data && (
            <div className="px-4 py-3 mb-2 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-bold text-blue-700 dark:text-blue-300">
                    Level {profile.data.level || 1}
                  </span>
                </div>
                <span className="text-xs text-blue-600 dark:text-blue-400">
                  {profile.data.xp || 0} / {(profile.data.level || 1) * 200} XP
                </span>
              </div>
              <Progress 
                value={((profile.data.xp || 0) / ((profile.data.level || 1) * 200)) * 100} 
                className="h-2 bg-blue-200 dark:bg-blue-800"
              />
            </div>
          )}
          
          <button 
            onClick={() => logout()} 
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-[#F8F9FC]">
        <div className="max-w-7xl mx-auto p-4 md:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
