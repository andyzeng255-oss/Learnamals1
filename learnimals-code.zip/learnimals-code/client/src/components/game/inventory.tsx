import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Package, Shirt, Sofa, Lock, Check } from "lucide-react";

interface Accessory {
  id: number;
  name: string;
  type: string;
  cost: number;
  minLevel: number;
  imageUrl: string;
}

interface PetAccessory {
  id: number;
  accessoryId: number;
  isEquipped: boolean;
  accessory: Accessory;
}

interface Furniture {
  id: number;
  name: string;
  type: string;
  cost: number;
  imageUrl: string;
}

interface InventoryProps {
  petId: number;
  petLevel: number;
  studentCoins: number;
}

export function Inventory({ petId, petLevel, studentCoins }: InventoryProps) {
  const { data: petAccessories = [] } = useQuery<PetAccessory[]>({
    queryKey: [`/api/pets/${petId}/accessories`],
  });

  const { data: allAccessories = [] } = useQuery<Accessory[]>({
    queryKey: ['/api/accessories'],
  });

  const { data: allFurniture = [] } = useQuery<Furniture[]>({
    queryKey: ['/api/furniture'],
  });

  const equipMutation = useMutation({
    mutationFn: async ({ accessoryId, type }: { accessoryId: number; type: string }) => {
      await apiRequest("POST", `/api/pets/${petId}/accessories/${accessoryId}/equip`, { type });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/pets/${petId}/accessories`] });
    }
  });

  const unlockMutation = useMutation({
    mutationFn: async (accessoryId: number) => {
      await apiRequest("POST", `/api/pets/${petId}/accessories/${accessoryId}/unlock`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/pets/${petId}/accessories`] });
    }
  });

  const unlockedIds = new Set(petAccessories.map(pa => pa.accessoryId));
  const equippedIds = new Set(petAccessories.filter(pa => pa.isEquipped).map(pa => pa.accessoryId));

  const groupedAccessories = allAccessories.reduce((acc, item) => {
    if (!acc[item.type]) acc[item.type] = [];
    acc[item.type].push(item);
    return acc;
  }, {} as Record<string, Accessory[]>);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5 text-primary" />
            Inventory
          </CardTitle>
          <Badge variant="secondary" data-testid="badge-coins">
            {studentCoins} Coins
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="accessories">
          <TabsList className="w-full">
            <TabsTrigger value="accessories" className="flex-1" data-testid="tab-accessories">
              <Shirt className="h-4 w-4 mr-2" />
              Accessories
            </TabsTrigger>
            <TabsTrigger value="furniture" className="flex-1" data-testid="tab-furniture">
              <Sofa className="h-4 w-4 mr-2" />
              Furniture
            </TabsTrigger>
          </TabsList>

          <TabsContent value="accessories" className="mt-4">
            {Object.entries(groupedAccessories).map(([type, items]) => (
              <div key={type} className="mb-4">
                <h4 className="text-sm font-medium mb-2 capitalize">{type}s</h4>
                <div className="grid grid-cols-3 gap-2">
                  {items.map(accessory => {
                    const isUnlocked = unlockedIds.has(accessory.id);
                    const isEquipped = equippedIds.has(accessory.id);
                    const canUnlock = petLevel >= accessory.minLevel && studentCoins >= accessory.cost;

                    return (
                      <div
                        key={accessory.id}
                        className={`relative p-3 rounded-lg border-2 text-center ${
                          isEquipped ? 'border-primary bg-primary/5' : 'border-border'
                        }`}
                        data-testid={`item-accessory-${accessory.id}`}
                      >
                        <div className="w-12 h-12 mx-auto mb-2 bg-muted rounded-lg flex items-center justify-center">
                          {!isUnlocked && <Lock className="h-6 w-6 text-muted-foreground" />}
                          {isUnlocked && isEquipped && <Check className="h-6 w-6 text-primary" />}
                          {isUnlocked && !isEquipped && <Shirt className="h-6 w-6" />}
                        </div>
                        <p className="text-xs font-medium truncate">{accessory.name}</p>
                        {!isUnlocked && (
                          <p className="text-xs text-muted-foreground">
                            Lv.{accessory.minLevel} | {accessory.cost}c
                          </p>
                        )}
                        {!isUnlocked && canUnlock && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="mt-2 w-full"
                            onClick={() => unlockMutation.mutate(accessory.id)}
                            data-testid={`button-unlock-${accessory.id}`}
                          >
                            Unlock
                          </Button>
                        )}
                        {isUnlocked && !isEquipped && (
                          <Button
                            size="sm"
                            className="mt-2 w-full"
                            onClick={() => equipMutation.mutate({ accessoryId: accessory.id, type: accessory.type })}
                            data-testid={`button-equip-${accessory.id}`}
                          >
                            Equip
                          </Button>
                        )}
                        {isEquipped && (
                          <Badge variant="default" className="mt-2">Equipped</Badge>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
            {Object.keys(groupedAccessories).length === 0 && (
              <p className="text-center text-muted-foreground py-8">
                No accessories available yet.
              </p>
            )}
          </TabsContent>

          <TabsContent value="furniture" className="mt-4">
            <div className="grid grid-cols-3 gap-2">
              {allFurniture.map(item => (
                <div
                  key={item.id}
                  className="p-3 rounded-lg border-2 border-border text-center"
                  data-testid={`item-furniture-${item.id}`}
                >
                  <div className="w-12 h-12 mx-auto mb-2 bg-muted rounded-lg flex items-center justify-center">
                    <Sofa className="h-6 w-6" />
                  </div>
                  <p className="text-xs font-medium truncate">{item.name}</p>
                  <p className="text-xs text-muted-foreground">{item.cost}c</p>
                </div>
              ))}
            </div>
            {allFurniture.length === 0 && (
              <p className="text-center text-muted-foreground py-8">
                No furniture available yet.
              </p>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
