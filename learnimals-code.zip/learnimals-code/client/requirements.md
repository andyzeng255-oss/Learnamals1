## Packages
phaser | Game engine for the pet room
framer-motion | For smooth UI transitions and animations
lucide-react | Icons
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Fredoka'", "sans-serif"],
  body: ["'DM Sans'", "sans-serif"],
}
