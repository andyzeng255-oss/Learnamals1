import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Dashboard from "@/pages/dashboard";
import Classroom from "@/pages/classroom";
import TeacherDashboard from "@/pages/teacher-dashboard";
import TeacherHomework from "@/pages/teacher-homework";
import Onboarding from "@/pages/onboarding";
import { useAuth } from "@/hooks/use-auth";
import { useProfile } from "@/hooks/use-profile";
import { useEffect } from "react";
import { Loader2 } from "lucide-react";

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { data: profile, isLoading: isProfileLoading } = useProfile();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setLocation("/");
    }
  }, [isLoading, isAuthenticated, setLocation]);

  if (isLoading || isProfileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  if (isAuthenticated && !profile?.data) {
    return <Onboarding />;
  }

  return isAuthenticated ? <Component /> : null;
}

function HomeRoute() {
  const { isAuthenticated, isLoading } = useAuth();
  const { data: profile, isLoading: isProfileLoading } = useProfile();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && !isProfileLoading && isAuthenticated && profile?.data) {
      if (profile.type === 'teacher') {
        setLocation('/teacher-dashboard');
      } else {
        setLocation('/dashboard');
      }
    }
  }, [isLoading, isProfileLoading, isAuthenticated, profile, setLocation]);

  if (isLoading || isProfileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Landing />;
  }

  if (!profile?.data) {
    return <Onboarding />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Loader2 className="w-10 h-10 animate-spin text-primary" />
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomeRoute} />
      <Route path="/dashboard">
        <ProtectedRoute component={Dashboard} />
      </Route>
      <Route path="/classroom">
        <ProtectedRoute component={Classroom} />
      </Route>
      <Route path="/teacher-dashboard">
        <ProtectedRoute component={TeacherDashboard} />
      </Route>
      <Route path="/teacher-classrooms">
        <ProtectedRoute component={TeacherDashboard} />
      </Route>
      <Route path="/teacher-homework">
        <ProtectedRoute component={TeacherHomework} />
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
