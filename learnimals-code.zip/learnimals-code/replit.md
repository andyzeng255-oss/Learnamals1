# Learnimals

## Overview

Learnimals is a gamified educational platform where students adopt virtual pets, complete classroom assignments, and earn XP to level up their pets. Teachers can create classrooms, assign work, and track student progress. The platform features a Phaser-based pet room with grid-based furniture placement, an AI-powered practice question system, and a pet evolution/accessory system.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state, with custom hooks per domain (pets, classrooms, assignments, room)
- **UI Components**: shadcn/ui component library with Radix UI primitives, styled with Tailwind CSS
- **Game Engine**: Phaser 3 for the interactive pet room with grid-based drag-and-drop furniture system
- **Styling**: Tailwind CSS with custom design tokens (Fredoka display font, DM Sans body font, playful color palette)

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful endpoints defined in `shared/routes.ts` with Zod schemas for validation
- **Authentication**: Replit Auth integration using OpenID Connect with Passport.js, session storage in PostgreSQL
- **AI Integration**: OpenAI API (via Replit AI Integrations) for generating practice questions and images

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: `shared/schema.ts` defines all tables (students, teachers, classrooms, pets, accessories, furniture, assignments, room items)
- **Migrations**: Drizzle Kit with `db:push` command for schema synchronization

### Key Domain Models
- **Users**: Split into students (with grade level, coins, XP) and teachers (with subject)
- **Pets**: Owned by students with XP, levels, evolution stages, happiness/hunger stats, and equipped accessories
- **Classrooms**: Created by teachers with join codes; students can join multiple classrooms
- **Assignments**: Belong to classrooms with content, max points, and grade level filtering
- **Room Items**: Grid-positioned furniture pieces placed in student pet rooms

### Authentication Flow
- Replit Auth handles login via `/api/login` and `/api/logout`
- Sessions stored in PostgreSQL `sessions` table
- New users go through onboarding to choose student or teacher role
- Protected routes check authentication and redirect to landing page if not logged in

## External Dependencies

### Third-Party Services
- **Replit Auth**: OpenID Connect authentication via Replit's identity provider
- **OpenAI API**: Used for AI-generated practice questions and image generation (accessed through Replit AI Integrations)
- **PostgreSQL**: Primary database (provisioned via Replit)

### Key NPM Packages
- **phaser**: Game engine for pet room interactions
- **drizzle-orm / drizzle-kit**: Database ORM and migration tooling
- **@tanstack/react-query**: Server state management
- **openai**: AI API client for questions and images
- **passport / openid-client**: Authentication handling
- **zod / drizzle-zod**: Schema validation and type generation
- **connect-pg-simple**: PostgreSQL session store