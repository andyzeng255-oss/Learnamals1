import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, Trophy, Users, Heart, Star } from "lucide-react";

import foxMascot from "@assets/generated_images/cute_cartoon_fox_mascot.png";
import catMascot from "@assets/generated_images/cute_cartoon_cat_mascot.png";
import dogMascot from "@assets/generated_images/cute_cartoon_dog_mascot.png";
import snakeMascot from "@assets/generated_images/cute_cartoon_snake_mascot.png";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 via-orange-50 to-teal-50 font-body selection:bg-primary/20 selection:text-primary">
      {/* Navigation */}
      <nav className="fixed w-full bg-white/80 backdrop-blur-md z-50 border-b border-purple-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-2xl font-display shadow-lg shadow-primary/30">
              L
            </div>
            <span className="text-2xl font-bold font-display bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent tracking-tight">Learnimals</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="/api/login" className="text-gray-600 hover:text-primary font-medium hidden sm:block transition-colors">Sign In</a>
            <Button 
              className="rounded-full px-6 font-bold bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-lg shadow-primary/25"
              onClick={() => window.location.href = '/api/login'}
              data-testid="button-get-started"
            >
              Get Started <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden relative">
        {/* Floating decorative elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-yellow-300/30 rounded-full blur-2xl animate-pulse" />
        <div className="absolute top-40 right-20 w-32 h-32 bg-pink-300/30 rounded-full blur-2xl animate-pulse" />
        <div className="absolute bottom-20 left-1/4 w-24 h-24 bg-teal-300/30 rounded-full blur-2xl animate-pulse" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
            <div className="relative z-10">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-yellow-100 to-orange-100 text-orange-700 font-bold text-sm mb-6 border border-orange-200 shadow-sm">
                <Sparkles className="w-4 h-4 text-orange-500" />
                <span>Learning made magical</span>
                <Heart className="w-4 h-4 text-pink-500" />
              </div>
              <h1 className="text-5xl lg:text-7xl font-display font-bold text-gray-900 leading-[1.1] mb-6">
                Turn Homework into{" "}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-pink-500 to-accent">Adventure</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-lg leading-relaxed">
                Adopt a cute pet, decorate your room, and level up by completing classroom assignments. The most fun way to learn for students everywhere!
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="rounded-full text-lg h-14 px-8 bg-gradient-to-r from-primary to-pink-500 hover:opacity-90 shadow-xl shadow-primary/30 hover:-translate-y-1 transition-all duration-300"
                  onClick={() => window.location.href = '/api/login'}
                  data-testid="button-start-journey"
                >
                  <Star className="mr-2 w-5 h-5" /> Start Your Journey
                </Button>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="rounded-full text-lg h-14 px-8 border-2 border-accent hover:bg-accent/10 text-accent"
                  data-testid="button-for-teachers"
                >
                  For Teachers
                </Button>
              </div>
            </div>
            
            {/* Hero with cute animals */}
            <div className="relative">
              {/* Decorative blobs */}
              <div className="absolute -top-10 -right-10 w-72 h-72 bg-gradient-to-br from-primary/20 to-pink-300/20 rounded-full blur-3xl" />
              <div className="absolute -bottom-10 -left-10 w-56 h-56 bg-gradient-to-br from-yellow-300/30 to-orange-300/20 rounded-full blur-3xl" />
              
              {/* Animal mascots grid */}
              <div className="relative grid grid-cols-2 gap-4">
                <div className="bg-white rounded-3xl p-4 shadow-xl border-4 border-purple-100 hover:scale-105 transition-transform duration-300 hover:rotate-2">
                  <img src={foxMascot} alt="Cute fox pet" className="w-full h-auto" />
                  <div className="text-center mt-2">
                    <span className="font-display font-bold text-primary">Foxy</span>
                    <div className="flex justify-center gap-1 mt-1">
                      <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                      <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                      <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    </div>
                  </div>
                </div>
                
                <div className="bg-white rounded-3xl p-4 shadow-xl border-4 border-teal-100 hover:scale-105 transition-transform duration-300 hover:-rotate-2 mt-8">
                  <img src={catMascot} alt="Cute cat pet" className="w-full h-auto" />
                  <div className="text-center mt-2">
                    <span className="font-display font-bold text-accent">Whiskers</span>
                    <div className="flex justify-center gap-1 mt-1">
                      <Heart className="w-4 h-4 text-pink-400 fill-pink-400" />
                      <Heart className="w-4 h-4 text-pink-400 fill-pink-400" />
                    </div>
                  </div>
                </div>
                
                <div className="bg-white rounded-3xl p-4 shadow-xl border-4 border-yellow-100 hover:scale-105 transition-transform duration-300 hover:-rotate-2 -mt-4">
                  <img src={dogMascot} alt="Cute dog pet" className="w-full h-auto" />
                  <div className="text-center mt-2">
                    <span className="font-display font-bold text-yellow-600">Buddy</span>
                    <div className="flex justify-center gap-1 mt-1">
                      <Sparkles className="w-4 h-4 text-orange-400" />
                      <Sparkles className="w-4 h-4 text-orange-400" />
                    </div>
                  </div>
                </div>
                
                <div className="bg-white rounded-3xl p-4 shadow-xl border-4 border-green-100 hover:scale-105 transition-transform duration-300 hover:rotate-2">
                  <img src={snakeMascot} alt="Cute snake pet" className="w-full h-auto" />
                  <div className="text-center mt-2">
                    <span className="font-display font-bold text-green-600">Slither</span>
                    <div className="flex justify-center gap-1 mt-1">
                      <Star className="w-4 h-4 text-green-400 fill-green-400" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-white/60 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-4xl font-display font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-4">Level Up Your Learning</h2>
            <p className="text-lg text-gray-600">Combine education with gamification to keep students engaged and motivated to achieve more.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-orange-50 to-yellow-50 p-8 rounded-3xl shadow-lg border-2 border-orange-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-400 to-yellow-400 flex items-center justify-center text-white mb-6 shadow-lg shadow-orange-200">
                <Sparkles className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold font-display text-gray-900 mb-3">Adopt a Pet</h3>
              <p className="text-gray-600 leading-relaxed">Choose your companion and watch them grow as you complete your assignments and earn XP.</p>
            </div>
            
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-8 rounded-3xl shadow-lg border-2 border-purple-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-pink-500 flex items-center justify-center text-white mb-6 shadow-lg shadow-purple-200">
                <Users className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold font-display text-gray-900 mb-3">Virtual Classroom</h3>
              <p className="text-gray-600 leading-relaxed">Teachers can assign tasks, track progress, and award coins for exceptional work.</p>
            </div>
            
            <div className="bg-gradient-to-br from-teal-50 to-cyan-50 p-8 rounded-3xl shadow-lg border-2 border-teal-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-accent to-cyan-400 flex items-center justify-center text-white mb-6 shadow-lg shadow-teal-200">
                <Trophy className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold font-display text-gray-900 mb-3">Earn Rewards</h3>
              <p className="text-gray-600 leading-relaxed">Use your hard-earned coins to buy furniture, accessories, and upgrades for your room.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Pet showcase */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-pink-500/5 to-accent/5" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-display font-bold text-gray-900 mb-4">Meet Your Future Pets</h2>
            <p className="text-lg text-gray-600">Each pet has unique personalities and grows with you on your learning journey!</p>
          </div>
          
          <div className="flex flex-wrap justify-center gap-6">
            {[
              { img: foxMascot, name: "Fox", color: "from-orange-400 to-red-400", desc: "Clever & Quick" },
              { img: catMascot, name: "Cat", color: "from-purple-400 to-pink-400", desc: "Curious & Smart" },
              { img: dogMascot, name: "Dog", color: "from-yellow-400 to-orange-400", desc: "Loyal & Friendly" },
              { img: snakeMascot, name: "Snake", color: "from-green-400 to-teal-400", desc: "Wise & Calm" },
            ].map((pet, i) => (
              <div key={i} className="bg-white rounded-3xl p-6 shadow-xl border-2 border-gray-100 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 w-48">
                <img src={pet.img} alt={pet.name} className="w-32 h-32 mx-auto mb-4" />
                <div className={`text-center font-display font-bold text-lg bg-gradient-to-r ${pet.color} bg-clip-text text-transparent`}>
                  {pet.name}
                </div>
                <div className="text-center text-sm text-gray-500 mt-1">{pet.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-primary via-pink-500 to-accent">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl lg:text-5xl font-display font-bold text-white mb-6">Ready to Start Learning?</h2>
          <p className="text-xl text-white/90 mb-8">Join thousands of students who are already having fun while learning!</p>
          <Button 
            size="lg" 
            className="rounded-full text-lg h-14 px-10 bg-white text-primary hover:bg-white/90 shadow-xl hover:-translate-y-1 transition-all duration-300"
            onClick={() => window.location.href = '/api/login'}
            data-testid="button-join-now"
          >
            Join Now - It's Free! <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-gray-900 text-white/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-sm font-display">
              L
            </div>
            <span className="font-display font-bold text-white">Learnimals</span>
          </div>
          <p className="text-sm">Making learning fun, one pet at a time.</p>
        </div>
      </footer>
    </div>
  );
}
