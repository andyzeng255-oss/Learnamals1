import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { ShoppingBag, Sofa, Apple, Package, Coins, Lock, Check, ArrowUpDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface StoreItem {
  id: number;
  name: string;
  description: string;
  category: string;
  cost: number;
  imageUrl?: string;
}

interface StoreProps {
  studentCoins: number;
  onPurchase?: () => void;
}

const CATEGORIES = [
  { id: "all", name: "All", icon: Package },
  { id: "decor", name: "Decor", icon: Sofa },
  { id: "items", name: "Items", icon: ShoppingBag },
  { id: "food", name: "Food", icon: Apple },
];

type SortOption = 'price-asc' | 'price-desc' | 'name-asc' | 'name-desc';

export function Store({ studentCoins, onPurchase }: StoreProps) {
  const [activeCategory, setActiveCategory] = useState("all");
  const [sortBy, setSortBy] = useState<SortOption>("price-asc");
  const [showAffordableOnly, setShowAffordableOnly] = useState(false);
  const { toast } = useToast();

  const { data: storeItems = [], isLoading } = useQuery<StoreItem[]>({
    queryKey: ['/api/store/items'],
  });

  const { data: ownedItems = [] } = useQuery<number[]>({
    queryKey: ['/api/store/owned'],
  });

  const purchaseMutation = useMutation({
    mutationFn: async (itemId: number) => {
      const res = await apiRequest("POST", "/api/store/purchase", { itemId });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Purchase failed");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/store/owned'] });
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
      if (onPurchase) onPurchase();
      toast({
        title: "Purchase Successful!",
        description: "Item has been added to your inventory.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Purchase Failed",
        description: error.message || "Not enough coins or item unavailable.",
        variant: "destructive",
      });
    }
  });

  const sortedAndFilteredItems = useMemo(() => {
    let items = activeCategory === "all" 
      ? [...storeItems]
      : storeItems.filter(item => item.category === activeCategory);
    
    if (showAffordableOnly) {
      const ownedSet = new Set(ownedItems);
      items = items.filter(item => !ownedSet.has(item.id) && item.cost <= studentCoins);
    }
    
    switch (sortBy) {
      case 'price-asc':
        items.sort((a, b) => a.cost - b.cost);
        break;
      case 'price-desc':
        items.sort((a, b) => b.cost - a.cost);
        break;
      case 'name-asc':
        items.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'name-desc':
        items.sort((a, b) => b.name.localeCompare(a.name));
        break;
    }
    return items;
  }, [storeItems, activeCategory, sortBy, showAffordableOnly, ownedItems, studentCoins]);

  const ownedSet = new Set(ownedItems);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "decor": return <Sofa className="h-6 w-6" />;
      case "items": return <ShoppingBag className="h-6 w-6" />;
      case "food": return <Apple className="h-6 w-6" />;
      default: return <Package className="h-6 w-6" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <CardTitle className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-primary" />
            Store
          </CardTitle>
          <Badge variant="secondary" className="flex items-center gap-1" data-testid="badge-store-coins">
            <Coins className="h-4 w-4" />
            {studentCoins} Coins
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeCategory} onValueChange={setActiveCategory}>
          <TabsList className="w-full grid grid-cols-4">
            {CATEGORIES.map(cat => (
              <TabsTrigger 
                key={cat.id} 
                value={cat.id} 
                className="flex items-center gap-1"
                data-testid={`tab-category-${cat.id}`}
              >
                <cat.icon className="h-4 w-4" />
                <span className="hidden sm:inline">{cat.name}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          <div className="flex items-center justify-between gap-2 mt-4 mb-3 flex-wrap">
            <div className="flex items-center gap-2">
              <Checkbox 
                id="affordable-only" 
                checked={showAffordableOnly} 
                onCheckedChange={(checked) => setShowAffordableOnly(checked === true)}
                data-testid="checkbox-affordable"
              />
              <Label htmlFor="affordable-only" className="text-sm cursor-pointer">
                Show only what I can afford
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
              <Select value={sortBy} onValueChange={(val) => setSortBy(val as SortOption)}>
                <SelectTrigger className="w-40" data-testid="select-sort">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="price-asc">Price: Low to High</SelectItem>
                  <SelectItem value="price-desc">Price: High to Low</SelectItem>
                  <SelectItem value="name-asc">Name: A to Z</SelectItem>
                  <SelectItem value="name-desc">Name: Z to A</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="">
            {isLoading ? (
              <div className="text-center py-8 text-muted-foreground">
                Loading store items...
              </div>
            ) : sortedAndFilteredItems.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Package className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No items available in this category yet.</p>
                <p className="text-sm">Check back later for new items!</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {sortedAndFilteredItems.map(item => {
                  const isOwned = ownedSet.has(item.id);
                  const canAfford = studentCoins >= item.cost;

                  return (
                    <div
                      key={item.id}
                      className={`relative p-3 rounded-lg border-2 text-center transition-all ${
                        isOwned 
                          ? 'border-green-500 bg-green-50 dark:bg-green-950/20' 
                          : canAfford 
                            ? 'border-border hover:border-primary hover:shadow-md' 
                            : 'border-border opacity-60'
                      }`}
                      data-testid={`store-item-${item.id}`}
                    >
                      <div className="w-14 h-14 mx-auto mb-2 bg-muted rounded-lg flex items-center justify-center">
                        {getCategoryIcon(item.category)}
                      </div>
                      <p className="text-sm font-medium truncate">{item.name}</p>
                      <p className="text-xs text-muted-foreground truncate mb-2">{item.description}</p>
                      
                      {isOwned ? (
                        <Badge variant="default" className="bg-green-500">
                          <Check className="h-3 w-3 mr-1" />
                          Owned
                        </Badge>
                      ) : (
                        <>
                          <div className="flex items-center justify-center gap-1 text-sm font-bold mb-2">
                            <Coins className="h-4 w-4 text-yellow-500" />
                            {item.cost}
                          </div>
                          <Button
                            size="sm"
                            className="w-full"
                            disabled={!canAfford || purchaseMutation.isPending}
                            onClick={() => purchaseMutation.mutate(item.id)}
                            data-testid={`button-buy-${item.id}`}
                          >
                            {!canAfford && <Lock className="h-3 w-3 mr-1" />}
                            {purchaseMutation.isPending ? "..." : canAfford ? "Buy" : "Need Coins"}
                          </Button>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </Tabs>
      </CardContent>
    </Card>
  );
}
