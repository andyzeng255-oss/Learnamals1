import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Sparkles, CheckCircle, XCircle, Loader2, Brain } from "lucide-react";

interface Question {
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
}

interface PracticeQuestionsProps {
  gradeLevel: number;
  petId: number;
  onXpEarned?: (xp: number) => void;
}

export function PracticeQuestions({ gradeLevel, petId, onXpEarned }: PracticeQuestionsProps) {
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState({ correct: 0, total: 0 });
  const [subject, setSubject] = useState("Math");

  const generateMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/ai/generate", {
        subject,
        gradeLevel,
        topic: undefined
      });
      return res.json();
    },
    onSuccess: (data: Question) => {
      setCurrentQuestion(data);
      setSelectedAnswer(null);
      setIsAnswered(false);
    }
  });

  const handleAnswer = (answer: string) => {
    if (isAnswered) return;
    setSelectedAnswer(answer);
    setIsAnswered(true);
    
    const isCorrect = answer === currentQuestion?.correctAnswer;
    setScore(prev => ({
      correct: prev.correct + (isCorrect ? 1 : 0),
      total: prev.total + 1
    }));

    if (isCorrect && onXpEarned) {
      onXpEarned(5);
    }
  };

  const subjects = ["Math", "Science", "Reading", "History"];

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-primary" />
            Practice Questions
          </CardTitle>
          {score.total > 0 && (
            <Badge variant="secondary" data-testid="badge-score">
              Score: {score.correct}/{score.total}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2 flex-wrap">
          {subjects.map(s => (
            <Button
              key={s}
              size="sm"
              variant={subject === s ? "default" : "outline"}
              onClick={() => setSubject(s)}
              data-testid={`button-subject-${s.toLowerCase()}`}
            >
              {s}
            </Button>
          ))}
        </div>

        {!currentQuestion && !generateMutation.isPending && (
          <div className="text-center py-8">
            <p className="text-muted-foreground mb-4">
              Ready to earn XP for your pet? Generate a {subject} question!
            </p>
            <Button 
              onClick={() => generateMutation.mutate()}
              data-testid="button-generate-question"
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Generate Question
            </Button>
          </div>
        )}

        {generateMutation.isPending && (
          <div className="text-center py-8">
            <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
            <p className="text-muted-foreground mt-2">Generating question...</p>
          </div>
        )}

        {currentQuestion && (
          <div className="space-y-4">
            <div className="p-4 bg-muted rounded-lg">
              <p className="font-medium" data-testid="text-question">{currentQuestion.question}</p>
            </div>

            <div className="grid gap-2">
              {currentQuestion.options.map((option, index) => {
                const isSelected = selectedAnswer === option;
                const isCorrect = option === currentQuestion.correctAnswer;
                const showResult = isAnswered;

                let variant: "default" | "outline" | "destructive" | "secondary" = "outline";
                if (showResult && isCorrect) variant = "default";
                if (showResult && isSelected && !isCorrect) variant = "destructive";

                return (
                  <Button
                    key={index}
                    variant={variant}
                    className="justify-start h-auto py-3 px-4"
                    onClick={() => handleAnswer(option)}
                    disabled={isAnswered}
                    data-testid={`button-option-${index}`}
                  >
                    <span className="mr-2">{String.fromCharCode(65 + index)}.</span>
                    {option}
                    {showResult && isCorrect && (
                      <CheckCircle className="h-4 w-4 ml-auto text-green-500" />
                    )}
                    {showResult && isSelected && !isCorrect && (
                      <XCircle className="h-4 w-4 ml-auto" />
                    )}
                  </Button>
                );
              })}
            </div>

            {isAnswered && (
              <div className="p-4 bg-muted rounded-lg space-y-2">
                {selectedAnswer === currentQuestion.correctAnswer ? (
                  <p className="text-green-600 font-medium flex items-center gap-2">
                    <CheckCircle className="h-4 w-4" />
                    Correct! +5 XP
                  </p>
                ) : (
                  <p className="text-destructive font-medium flex items-center gap-2">
                    <XCircle className="h-4 w-4" />
                    Incorrect
                  </p>
                )}
                <p className="text-sm text-muted-foreground">{currentQuestion.explanation}</p>
              </div>
            )}
          </div>
        )}
      </CardContent>
      {isAnswered && (
        <CardFooter>
          <Button 
            onClick={() => generateMutation.mutate()} 
            className="w-full"
            data-testid="button-next-question"
          >
            Next Question
          </Button>
        </CardFooter>
      )}
    </Card>
  );
}
