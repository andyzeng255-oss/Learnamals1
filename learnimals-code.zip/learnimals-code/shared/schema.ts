import { pgTable, text, serial, integer, boolean, timestamp, jsonb, primaryKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";
import { users } from "./models/auth";

export * from "./models/auth";
export * from "./models/chat";

// === ENTITIES ===

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(), // References auth.users.id
  gradeLevel: integer("grade_level").default(1).notNull(),
  coins: integer("coins").default(0).notNull(),
  xp: integer("xp").default(0).notNull(),
  level: integer("level").default(1).notNull(),
});

export const teachers = pgTable("teachers", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(), // References auth.users.id
  subject: text("subject"),
});

export const classrooms = pgTable("classrooms", {
  id: serial("id").primaryKey(),
  teacherId: integer("teacher_id").notNull(), // References teachers.id
  name: text("name").notNull(),
  code: text("code").notNull().unique(), // For students to join
});

export const classroomStudents = pgTable("classroom_students", {
  id: serial("id").primaryKey(),
  classroomId: integer("classroom_id").notNull(), // References classrooms.id
  studentId: integer("student_id").notNull(), // References students.id
});

// === PETS ===
export const pets = pgTable("pets", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  xp: integer("xp").default(0).notNull(),
  level: integer("level").default(1).notNull(),
  evolutionStage: integer("evolution_stage").default(1).notNull(),
  happiness: integer("happiness").default(100).notNull(),
  hunger: integer("hunger").default(0).notNull(),
  isHatched: boolean("is_hatched").default(true).notNull(),
  activeAccessories: jsonb("active_accessories").default({}).notNull(), // { hat: id, glasses: id, collar: id }
});

export const accessories = pgTable("accessories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  cost: integer("cost").default(0).notNull(),
  minLevel: integer("min_level").default(1).notNull(),
  imageUrl: text("image_url").notNull(),
});

export const petAccessories = pgTable("pet_accessories", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id").notNull(),
  accessoryId: integer("accessory_id").notNull(),
  isEquipped: boolean("is_equipped").default(false).notNull(),
  unlockedAt: timestamp("unlocked_at").defaultNow(),
});

export const furniture = pgTable("furniture", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'bed', 'rug', 'lamp'
  width: integer("width").default(1).notNull(), // Grid width
  height: integer("height").default(1).notNull(), // Grid height
  cost: integer("cost").default(0).notNull(),
  imageUrl: text("image_url").notNull(),
});

export const roomItems = pgTable("room_items", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(), // References students.id
  furnitureId: integer("furniture_id").notNull(), // References furniture.id
  x: integer("x").default(0).notNull(),
  y: integer("y").default(0).notNull(),
  rotation: integer("rotation").default(0).notNull(),
});

export const assignments = pgTable("assignments", {
  id: serial("id").primaryKey(),
  classroomId: integer("classroom_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  content: jsonb("content").notNull(),
  maxPoints: integer("max_points").default(100).notNull(),
  xpReward: integer("xp_reward").default(50).notNull(),
  gradeLevel: integer("grade_level").notNull(),
  dueDate: timestamp("due_date"),
});

export const studentAssignments = pgTable("student_assignments", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  assignmentId: integer("assignment_id").notNull(),
  status: text("status").default("pending").notNull(),
  score: integer("score"),
  awardedXp: integer("awarded_xp").default(0).notNull(),
  completedAt: timestamp("completed_at"),
  feedback: text("feedback"),
});

export const classroomFolders = pgTable("classroom_folders", {
  id: serial("id").primaryKey(),
  classroomId: integer("classroom_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
});

export const storeItems = pgTable("store_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").default("").notNull(),
  category: text("category").notNull(),
  cost: integer("cost").default(10).notNull(),
  imageUrl: text("image_url"),
});

export const studentItems = pgTable("student_items", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  storeItemId: integer("store_item_id").notNull(),
  quantity: integer("quantity").default(1).notNull(),
  purchasedAt: timestamp("purchased_at").defaultNow(),
});

// === RELATIONS ===

export const studentsRelations = relations(students, ({ one, many }) => ({
  pets: many(pets),
  classroomStudents: many(classroomStudents),
  assignments: many(studentAssignments),
  roomItems: many(roomItems),
}));

export const teachersRelations = relations(teachers, ({ many }) => ({
  classrooms: many(classrooms),
}));

export const classroomsRelations = relations(classrooms, ({ one, many }) => ({
  teacher: one(teachers, {
    fields: [classrooms.teacherId],
    references: [teachers.id],
  }),
  students: many(classroomStudents),
  assignments: many(assignments),
}));

export const petsRelations = relations(pets, ({ one, many }) => ({
  student: one(students, {
    fields: [pets.studentId],
    references: [students.id],
  }),
  accessories: many(petAccessories),
}));

export const assignmentsRelations = relations(assignments, ({ one, many }) => ({
  classroom: one(classrooms, {
    fields: [assignments.classroomId],
    references: [classrooms.id],
  }),
  studentAssignments: many(studentAssignments),
}));

// === SCHEMAS ===

export const insertStudentSchema = createInsertSchema(students).omit({ id: true });
export const insertTeacherSchema = createInsertSchema(teachers).omit({ id: true });
export const insertClassroomSchema = createInsertSchema(classrooms).omit({ id: true });
export const insertPetSchema = createInsertSchema(pets).omit({ id: true, xp: true, level: true, evolutionStage: true, happiness: true, hunger: true });
export const insertAssignmentSchema = createInsertSchema(assignments).omit({ id: true });
export const insertRoomItemSchema = createInsertSchema(roomItems).omit({ id: true });

// === TYPES ===

export type Student = typeof students.$inferSelect;
export type Teacher = typeof teachers.$inferSelect;
export type Classroom = typeof classrooms.$inferSelect;
export type Pet = typeof pets.$inferSelect;
export type Accessory = typeof accessories.$inferSelect;
export type Furniture = typeof furniture.$inferSelect;
export type RoomItem = typeof roomItems.$inferSelect;
export type Assignment = typeof assignments.$inferSelect;
export type StudentAssignment = typeof studentAssignments.$inferSelect;
