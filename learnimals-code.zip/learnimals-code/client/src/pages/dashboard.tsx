import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { PetRoom, petDefinitions } from "@/components/game/pet-room";
import { PracticeQuestions } from "@/components/game/practice-questions";
import { Inventory } from "@/components/game/inventory";
import { Store } from "@/components/game/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card-custom";
import { useProfile } from "@/hooks/use-profile";
import { usePets, useCreatePet } from "@/hooks/use-pets";
import { Button } from "@/components/ui/button";
import { Plus, Coins, Trophy, Sparkles, BookOpen, Package, ShoppingBag, Edit2, GraduationCap, Star } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";

const createPetSchema = z.object({
  name: z.string().min(1, "Name is required"),
  type: z.string().min(1, "Type is required"),
});

export default function Dashboard() {
  const [location] = useLocation();
  const { data: profile } = useProfile();
  const { data: pets = [], isLoading } = usePets();
  const createPet = useCreatePet();
  const [open, setOpen] = useState(false);
  const [renameOpen, setRenameOpen] = useState(false);
  const [gradeOpen, setGradeOpen] = useState(false);
  const [selectedPetId, setSelectedPetId] = useState<number | null>(null);
  const [newPetName, setNewPetName] = useState("");
  
  const [activeTab, setActiveTab] = useState('room');

  // Sync tab state with URL query parameter
  useEffect(() => {
    const syncTabFromUrl = () => {
      const params = new URLSearchParams(window.location.search);
      const tab = params.get('tab');
      if (tab && ['room', 'practice', 'store', 'inventory'].includes(tab)) {
        setActiveTab(tab);
      } else {
        setActiveTab('room');
      }
    };
    
    // Initial sync
    syncTabFromUrl();
    
    // Listen for popstate events (triggered by sidebar navigation)
    window.addEventListener('popstate', syncTabFromUrl);
    return () => window.removeEventListener('popstate', syncTabFromUrl);
  }, []); // Only run on mount
  
  const form = useForm({
    resolver: zodResolver(createPetSchema),
    defaultValues: {
      name: "",
      type: "fox"
    }
  });

  const onSubmit = async (data: any) => {
    await createPet.mutateAsync(data);
    setOpen(false);
    form.reset();
  };

  const awardXpMutation = useMutation({
    mutationFn: async (xp: number) => {
      if (!selectedPet) return;
      await apiRequest("POST", "/api/practice/earn-xp", {
        petId: selectedPet.id,
        xp
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/pets'] });
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
    }
  });

  const renamePetMutation = useMutation({
    mutationFn: async (name: string) => {
      if (!selectedPet) return;
      await apiRequest("PATCH", `/api/pets/${selectedPet.id}`, { name });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/pets'] });
      setRenameOpen(false);
      setNewPetName("");
    }
  });

  const updateGradeMutation = useMutation({
    mutationFn: async (gradeLevel: number) => {
      await apiRequest("PATCH", "/api/profile/student", { gradeLevel });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
      setGradeOpen(false);
    }
  });

  if (isLoading) return <Layout><div className="flex items-center justify-center h-64">Loading...</div></Layout>;

  const hasPets = pets && pets.length > 0;
  const selectedPet = hasPets ? (pets.find(p => p.id === selectedPetId) || pets[0]) : null;

  if (selectedPet && selectedPetId !== selectedPet.id) {
    setSelectedPetId(selectedPet.id);
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-1">My Room</h1>
            <p className="text-muted-foreground">Welcome back to your personal space!</p>
          </div>
          
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-2 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300 px-4 py-2 rounded-full font-bold border border-yellow-200 dark:border-yellow-800">
              <Coins className="w-5 h-5" />
              <span data-testid="text-coins">{profile?.data?.coins || 0} Coins</span>
            </div>
            <div className="flex items-center gap-2 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 px-4 py-2 rounded-full font-bold border border-blue-200 dark:border-blue-800">
              <Star className="w-5 h-5" />
              <span data-testid="text-user-level">Level {profile?.data?.level || 1}</span>
            </div>
            <Dialog open={gradeOpen} onOpenChange={setGradeOpen}>
              <DialogTrigger asChild>
                <button 
                  className="flex items-center gap-2 bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 px-4 py-2 rounded-full font-bold border border-purple-200 dark:border-purple-800 hover:bg-purple-200 dark:hover:bg-purple-900/50 transition-colors cursor-pointer"
                  data-testid="button-grade-select"
                >
                  <GraduationCap className="w-5 h-5" />
                  <span data-testid="text-grade">Grade {profile?.data?.gradeLevel || 1}</span>
                  <Edit2 className="w-3 h-3" />
                </button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-sm">
                <DialogHeader>
                  <DialogTitle>Change Grade Level</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <p className="text-sm text-muted-foreground">Select your grade level to get practice questions suited for you.</p>
                  <Select 
                    defaultValue={String(profile?.data?.gradeLevel || 1)} 
                    onValueChange={(val) => updateGradeMutation.mutate(parseInt(val))}
                  >
                    <SelectTrigger data-testid="select-grade-level">
                      <SelectValue placeholder="Select grade" />
                    </SelectTrigger>
                    <SelectContent>
                      {[1,2,3,4,5,6,7,8,9,10,11,12].map(grade => (
                        <SelectItem key={grade} value={String(grade)}>Grade {grade}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {hasPets && (
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex gap-2 flex-wrap">
              {pets.map((pet) => (
                <button
                  key={pet.id}
                  onClick={() => setSelectedPetId(pet.id)}
                  className={`p-3 rounded-xl border-2 transition-all ${
                    selectedPetId === pet.id 
                      ? 'border-primary bg-primary/10 scale-105' 
                      : 'border-gray-200 hover:border-primary/50'
                  }`}
                  data-testid={`button-select-pet-${pet.id}`}
                >
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-lg mb-1">
                    {pet.name.charAt(0)}
                  </div>
                  <div className="text-xs font-medium truncate max-w-16">{pet.name}</div>
                  <div className="text-xs text-muted-foreground">Lv.{pet.level}</div>
                </button>
              ))}
            </div>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" data-testid="button-adopt-new">
                  <Plus className="w-4 h-4 mr-2" />
                  Adopt New Pet
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Adopt a New Friend</DialogTitle>
                </DialogHeader>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Pet Name</label>
                    <Input {...form.register("name")} placeholder="e.g. Fluffy" data-testid="input-pet-name" />
                    {form.formState.errors.name && <p className="text-destructive text-sm">{form.formState.errors.name.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Type</label>
                    <select 
                      {...form.register("type")}
                      className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                      data-testid="select-pet-type"
                    >
                      {petDefinitions.map(def => (
                        <option key={def.type} value={def.type}>{def.name}</option>
                      ))}
                    </select>
                  </div>
                  <Button type="submit" className="w-full" disabled={createPet.isPending} data-testid="button-confirm-adopt">
                    {createPet.isPending ? "Adopting..." : "Adopt Now"}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>

            {selectedPet && (
              <Dialog open={renameOpen} onOpenChange={setRenameOpen}>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="sm" data-testid="button-rename-pet">
                    <Edit2 className="w-4 h-4 mr-2" />
                    Rename Pet
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-sm">
                  <DialogHeader>
                    <DialogTitle>Rename {selectedPet.name}</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <Input 
                      value={newPetName} 
                      onChange={(e) => setNewPetName(e.target.value)}
                      placeholder="New name"
                      data-testid="input-new-pet-name"
                    />
                    <Button 
                      onClick={() => renamePetMutation.mutate(newPetName)}
                      disabled={!newPetName.trim() || renamePetMutation.isPending}
                      className="w-full"
                      data-testid="button-confirm-rename"
                    >
                      {renamePetMutation.isPending ? "Renaming..." : "Save New Name"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full max-w-lg grid grid-cols-4">
            <TabsTrigger value="room" data-testid="tab-room">
              <Sparkles className="w-4 h-4 mr-1" />
              <span className="hidden sm:inline">Pet Room</span>
            </TabsTrigger>
            <TabsTrigger value="practice" data-testid="tab-practice">
              <BookOpen className="w-4 h-4 mr-1" />
              <span className="hidden sm:inline">Practice</span>
            </TabsTrigger>
            <TabsTrigger value="store" data-testid="tab-store">
              <ShoppingBag className="w-4 h-4 mr-1" />
              <span className="hidden sm:inline">Store</span>
            </TabsTrigger>
            <TabsTrigger value="inventory" data-testid="tab-inventory">
              <Package className="w-4 h-4 mr-1" />
              <span className="hidden sm:inline">Inventory</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="room" className="mt-6">
            {selectedPet ? (
              <PetRoom pet={selectedPet} roomItems={[]} />
            ) : (
              <Card className="aspect-[4/3] flex flex-col items-center justify-center text-center p-12 bg-muted/50 border-dashed border-4 border-border">
                <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center text-muted-foreground mb-6">
                  <Plus className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-2">No Pets Yet</h3>
                <p className="text-muted-foreground mb-8 max-w-sm">Adopt your first pet to start your learning adventure!</p>
                <Dialog open={open} onOpenChange={setOpen}>
                  <DialogTrigger asChild>
                    <Button size="lg" className="rounded-full px-8 font-bold" data-testid="button-first-adopt">
                      Adopt a Pet
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Adopt a New Friend</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Pet Name</label>
                        <Input {...form.register("name")} placeholder="e.g. Fluffy" data-testid="input-pet-name-2" />
                        {form.formState.errors.name && <p className="text-destructive text-sm">{form.formState.errors.name.message}</p>}
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Type</label>
                        <select 
                          {...form.register("type")}
                          className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                          data-testid="select-pet-type-2"
                        >
                          {petDefinitions.map(def => (
                            <option key={def.type} value={def.type}>{def.name}</option>
                          ))}
                        </select>
                      </div>
                      <Button type="submit" className="w-full" disabled={createPet.isPending} data-testid="button-confirm-adopt-2">
                        {createPet.isPending ? "Adopting..." : "Adopt Now"}
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="practice" className="mt-6">
            {selectedPet ? (
              <PracticeQuestions 
                gradeLevel={profile?.data?.gradeLevel || 1}
                petId={selectedPet.id}
                onXpEarned={(xp) => awardXpMutation.mutate(xp)}
              />
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-muted-foreground">Adopt a pet first to start earning XP!</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="store" className="mt-6">
            <Store 
              studentCoins={profile?.data?.coins || 0}
              onPurchase={() => queryClient.invalidateQueries({ queryKey: ['/api/profile'] })}
            />
          </TabsContent>

          <TabsContent value="inventory" className="mt-6">
            {selectedPet ? (
              <Inventory 
                petId={selectedPet.id}
                petLevel={selectedPet.level}
                studentCoins={profile?.data?.coins || 0}
              />
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-muted-foreground">Adopt a pet first to view inventory!</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
