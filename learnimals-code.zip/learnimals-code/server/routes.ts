import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerImageRoutes } from "./replit_integrations/image";
import { db } from "./db";
import { classrooms, accessories, furniture, storeItems, studentItems, students } from "@shared/schema";
import { eq, and } from "drizzle-orm";

import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Integrations
  await setupAuth(app);
  registerAuthRoutes(app);
  registerChatRoutes(app);
  registerImageRoutes(app);

  // Helper to get authenticated user ID
  // Note: auth middleware ensures req.user is populated
  const getUserId = (req: any) => req.user?.claims?.sub;

  // === PROFILES ===
  app.get(api.profile.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    
    const student = await storage.getStudent(userId);
    if (student) return res.json({ type: 'student', data: student });

    const teacher = await storage.getTeacher(userId);
    if (teacher) return res.json({ type: 'teacher', data: teacher });

    res.json({ type: 'none', data: null });
  });

  app.post(api.profile.createStudent.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const data = api.profile.createStudent.input.parse(req.body);
    const student = await storage.createStudent({ ...data, userId });
    res.status(201).json(student);
  });

  app.post(api.profile.createTeacher.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const data = api.profile.createTeacher.input.parse(req.body);
    const teacher = await storage.createTeacher({ ...data, userId });
    res.status(201).json(teacher);
  });

  app.patch(api.profile.updateStudent.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const student = await storage.getStudent(userId);
    if (!student) return res.status(404).send("Student not found");
    
    const data = api.profile.updateStudent.input.parse(req.body);
    const updated = await storage.updateStudent(student.id, data);
    res.json(updated);
  });

  // === CLASSROOMS ===
  app.get(api.classrooms.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    
    // Check if teacher
    const teacher = await storage.getTeacher(userId);
    if (teacher) {
      const classrooms = await storage.getClassroomsByTeacher(teacher.id);
      return res.json(classrooms);
    }
    
    // Check if student
    const student = await storage.getStudent(userId);
    if (student) {
      const classrooms = await storage.getClassroomsByStudent(student.id);
      return res.json(classrooms);
    }
    
    res.status(400).send("Profile not found");
  });

  app.post(api.classrooms.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const teacher = await storage.getTeacher(userId);
    if (!teacher) return res.status(403).send("Only teachers can create classrooms");

    const data = api.classrooms.create.input.parse(req.body);
    const classroom = await storage.createClassroom({ ...data, teacherId: teacher.id });
    res.status(201).json(classroom);
  });

  app.post(api.classrooms.join.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const student = await storage.getStudent(userId);
    if (!student) return res.status(403).send("Only students can join classrooms");

    const { code } = api.classrooms.join.input.parse(req.body);
    const classroom = await storage.getClassroomByCode(code);
    if (!classroom) return res.status(404).json({ message: "Classroom not found" });

    await storage.addStudentToClassroom(classroom.id, student.id);
    res.json({ success: true });
  });

  // === PETS ===
  app.get(api.pets.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const student = await storage.getStudent(userId);
    if (!student) return res.json([]);

    const pets = await storage.getPetsByStudent(student.id);
    res.json(pets);
  });

  app.post(api.pets.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const student = await storage.getStudent(userId);
    if (!student) return res.status(403).send("Only students can create pets");

    const data = api.pets.create.input.parse(req.body);
    const pet = await storage.createPet({ ...data, studentId: student.id });
    res.status(201).json(pet);
  });

  app.get(api.pets.get.path, async (req, res) => {
    const pet = await storage.getPet(parseInt(req.params.id));
    if (!pet) return res.status(404).json({ message: "Pet not found" });
    
    // Also include accessories
    const accs = await storage.getPetAccessories(pet.id);
    res.json({ ...pet, accessories: accs });
  });

  app.patch(api.pets.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const petId = parseInt(req.params.id);
    const pet = await storage.getPet(petId);
    if (!pet) return res.status(404).json({ message: "Pet not found" });
    
    const data = api.pets.update.input.parse(req.body);
    const updated = await storage.updatePet(petId, data);
    res.json(updated);
  });

  app.post("/api/pets/:id/equip", async (req, res) => {
    const petId = parseInt(req.params.id);
    const { accessoryId, type } = req.body;
    await storage.equipAccessory(petId, accessoryId, type);
    res.json({ success: true });
  });

  app.get("/api/pets/:petId/accessories", async (req, res) => {
    const petId = parseInt(req.params.petId);
    const accs = await storage.getPetAccessories(petId);
    res.json(accs);
  });

  app.post("/api/pets/:petId/accessories/:accessoryId/equip", async (req, res) => {
    const petId = parseInt(req.params.petId);
    const accessoryId = parseInt(req.params.accessoryId);
    const { type } = req.body;
    await storage.equipAccessory(petId, accessoryId, type);
    res.json({ success: true });
  });

  app.post("/api/pets/:petId/accessories/:accessoryId/unlock", async (req, res) => {
    const petId = parseInt(req.params.petId);
    const accessoryId = parseInt(req.params.accessoryId);
    await storage.unlockAccessory(petId, accessoryId);
    res.json({ success: true });
  });

  // === ACCESSORIES & FURNITURE ===
  app.get("/api/accessories", async (req, res) => {
    const allAccessories = await db.select().from(accessories);
    res.json(allAccessories);
  });

  app.get("/api/furniture", async (req, res) => {
    const allFurniture = await db.select().from(furniture);
    res.json(allFurniture);
  });

  // === ROOM ===
  app.get(api.room.items.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const student = await storage.getStudent(userId);
    if (!student) return res.json([]);

    const items = await storage.getRoomItems(student.id);
    res.json(items);
  });

  app.post(api.room.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const student = await storage.getStudent(userId);
    if (!student) return res.status(403).send("Only students have rooms");

    const { items } = api.room.update.input.parse(req.body);
    const itemsWithStudent = items.map(i => ({ ...i, studentId: student.id }));
    const updated = await storage.updateRoomItems(student.id, itemsWithStudent);
    res.json(updated);
  });

  // === ASSIGNMENTS ===
  app.get(api.assignments.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const student = await storage.getStudent(userId);
    
    if (student) {
      // Get all classrooms for student, then get assignments
      // For MVP, just getting all assignments from all joined classrooms
      const classrooms = await storage.getClassroomsByStudent(student.id);
      let allAssignments: any[] = [];
      for (const cls of classrooms) {
        const asgs = await storage.getAssignmentsByClassroom(cls.id);
        allAssignments = [...allAssignments, ...asgs];
      }
      // TODO: Attach status from student_assignments
      res.json(allAssignments);
    } else {
      res.json([]);
    }
  });

  app.post(api.assignments.submit.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const student = await storage.getStudent(userId);
    if (!student) return res.status(403).send("Only students can submit assignments");

    const { score } = api.assignments.submit.input.parse(req.body);
    const assignmentId = parseInt(req.params.id);
    const { petId } = req.body; // Expect petId in body for reward

    if (!petId) return res.status(400).send("Pet ID is required for rewards");

    const submission = await storage.submitAssignment(student.id, assignmentId, score, petId);
    res.json(submission);
  });

  app.post("/api/teacher/award-xp", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const teacher = await storage.getTeacher(userId);
    if (!teacher) return res.status(403).send("Only teachers can award XP");

    const { studentId, petId, xp } = req.body;
    await storage.awardManualXp(studentId, petId, xp);
    res.json({ success: true });
  });

  // Student practice XP endpoint
  app.post("/api/practice/earn-xp", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const student = await storage.getStudent(userId);
    if (!student) return res.status(403).send("Only students can earn practice XP");

    const { petId, xp } = req.body;
    
    // Verify the pet belongs to this student
    const pet = await storage.getPet(petId);
    if (!pet || pet.studentId !== student.id) {
      return res.status(403).send("Pet does not belong to this student");
    }
    
    // Award pet XP
    await storage.awardManualXp(student.id, petId, xp);
    
    // Award user XP at 50% rate
    const userXp = Math.floor(xp * 0.5);
    const newUserXp = student.xp + userXp;
    const xpForNextLevel = student.level * 200;
    const newLevel = newUserXp >= xpForNextLevel ? student.level + 1 : student.level;
    
    await storage.updateStudent(student.id, {
      xp: newUserXp,
      level: newLevel
    });
    
    res.json({ success: true, petXp: xp, userXp: userXp, newUserLevel: newLevel });
  });

  app.post("/api/classrooms/:id/folders", async (req, res) => {
    const classroomId = parseInt(req.params.id);
    const data = req.body;
    const folder = await storage.createFolder({ ...data, classroomId });
    res.status(201).json(folder);
  });

  app.get("/api/classrooms/:id/folders", async (req, res) => {
    const classroomId = parseInt(req.params.id);
    const folders = await storage.getFolders(classroomId);
    res.json(folders);
  });

  // === STORE ===
  app.get("/api/store/items", async (req, res) => {
    const items = await db.select().from(storeItems);
    res.json(items);
  });

  app.get("/api/store/owned", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const student = await storage.getStudent(userId);
    if (!student) return res.json([]);

    const owned = await db.select({ storeItemId: studentItems.storeItemId })
      .from(studentItems)
      .where(eq(studentItems.studentId, student.id));
    res.json(owned.map(o => o.storeItemId));
  });

  app.post("/api/store/purchase", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const student = await storage.getStudent(userId);
    if (!student) return res.status(403).send("Only students can purchase items");

    const { itemId } = req.body;
    
    const [item] = await db.select().from(storeItems).where(eq(storeItems.id, itemId));
    if (!item) return res.status(404).json({ message: "Item not found" });

    if (student.coins < item.cost) {
      return res.status(400).json({ message: "Not enough coins" });
    }

    const [existingOwned] = await db.select().from(studentItems)
      .where(and(eq(studentItems.studentId, student.id), eq(studentItems.storeItemId, itemId)));
    
    if (existingOwned) {
      return res.status(400).json({ message: "You already own this item" });
    }

    await db.update(students).set({ coins: student.coins - item.cost }).where(eq(students.id, student.id));
    await db.insert(studentItems).values({ studentId: student.id, storeItemId: itemId });
    
    res.json({ success: true });
  });

  // === ACCESSORIES ===
  app.get("/api/accessories", async (req, res) => {
    const items = await db.select().from(accessories);
    res.json(items);
  });

  // === FURNITURE ===
  app.get("/api/furniture", async (req, res) => {
    const items = await db.select().from(furniture);
    res.json(items);
  });

  app.post(api.ai.generate.path, async (req, res) => {
    try {
      const { subject, gradeLevel, topic } = api.ai.generate.input.parse(req.body);
      
      const prompt = `Generate a multiple-choice ${subject} question for a student in grade ${gradeLevel}${topic ? ` about ${topic}` : ''}. 
      Provide the question, 4 options, the correct answer, and a brief explanation.
      Format the response as a JSON object with keys: question, options (array of 4 strings), correctAnswer (matching one of the options), and explanation.`;

      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      res.json(result);
    } catch (error) {
      console.error("AI Generation error:", error);
      res.status(500).json({ message: "Failed to generate AI question" });
    }
  });

  // === HOMEWORK ===
  app.post("/api/homework/generate", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    
    try {
      const { content, gradeLevel, numQuestions = 5 } = req.body;
      
      const prompt = `Based on the following educational content, generate ${numQuestions} multiple-choice questions appropriate for grade ${gradeLevel} students.
      
Content:
${content}

Generate questions that test understanding of the material. For each question:
- Make it clear and age-appropriate
- Provide 4 answer options
- Mark the correct answer
- Include a brief explanation

Return a JSON object with a "questions" array where each item has: question, options (array of 4 strings), correctAnswer (matching one of the options), explanation.`;

      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      res.json(result);
    } catch (error) {
      console.error("Homework generation error:", error);
      res.status(500).json({ message: "Failed to generate questions" });
    }
  });

  app.post("/api/homework/parse-pdf", async (req, res) => {
    res.json({ text: "", message: "PDF parsing not available - please paste the text directly" });
  });

  app.post("/api/homework", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const teacher = await storage.getTeacher(userId);
    if (!teacher) return res.status(403).send("Only teachers can create homework");

    const { title, classroomId, gradeLevel, questions, content } = req.body;
    
    const assignment = await storage.createAssignment({
      classroomId,
      title,
      content: JSON.stringify({ questions, originalContent: content }),
      maxPoints: questions.length * 10,
      gradeLevel: gradeLevel || null
    });
    
    res.status(201).json(assignment);
  });

  // Complete homework and award coins (extends existing assignment submission)
  app.post("/api/homework/:id/complete", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = getUserId(req);
    const student = await storage.getStudent(userId);
    if (!student) return res.status(403).send("Only students can complete homework");

    const assignmentId = parseInt(req.params.id);
    const { score, petId } = req.body;
    
    if (!score || !petId) {
      return res.status(400).json({ message: "Score and petId are required" });
    }
    
    // Calculate coin rewards based on user level
    const baseCoins = Math.floor(score / 10) * 5;
    const levelBonus = Math.floor(baseCoins * (student.level * 0.1));
    const totalCoins = baseCoins + levelBonus;
    
    // User XP is 50% of pet XP rate
    const userXp = Math.floor(score * 0.5);
    
    // submitAssignment handles pet XP - we only add user XP and coins here
    const submission = await storage.submitAssignment(student.id, assignmentId, score, petId);
    
    // Update user level (slower progression: level * 200 XP required)
    let newUserLevel = student.level;
    const newUserXp = student.xp + userXp;
    const xpForNextLevel = student.level * 200;
    if (newUserXp >= xpForNextLevel) {
      newUserLevel = student.level + 1;
    }
    
    // Award coins and user XP (pet XP already awarded by submitAssignment)
    await storage.updateStudent(student.id, {
      coins: student.coins + totalCoins,
      xp: newUserXp,
      level: newUserLevel
    });
    
    res.json({ 
      success: true, 
      coinsEarned: totalCoins,
      userXpEarned: userXp,
      newUserLevel: newUserLevel
    });
  });

  // === SEED DATA ===
  if (process.env.NODE_ENV !== "production") {
    const allClassrooms = await db.select().from(classrooms).limit(1);
    if (allClassrooms.length === 0) {
      console.log("Seeding database...");
      
      // Create Items
      await db.insert(accessories).values([
        { name: "Wizard Hat", type: "hat", cost: 100, imageUrl: "https://placehold.co/100x100/purple/white?text=Hat" },
        { name: "Bow Tie", type: "collar", cost: 50, imageUrl: "https://placehold.co/100x100/red/white?text=Tie" },
        { name: "Cool Shades", type: "glasses", cost: 150, imageUrl: "https://placehold.co/100x100/black/white?text=Glasses" },
      ]);
      
      await db.insert(furniture).values([
        { name: "Bean Bag", type: "seat", width: 2, height: 2, cost: 200, imageUrl: "https://placehold.co/200x200/blue/white?text=BeanBag" },
        { name: "Bookshelf", type: "storage", width: 2, height: 3, cost: 300, imageUrl: "https://placehold.co/200x300/brown/white?text=Shelf" },
        { name: "Rug", type: "floor", width: 3, height: 2, cost: 100, imageUrl: "https://placehold.co/300x200/green/white?text=Rug" },
      ]);

      await db.insert(storeItems).values([
        { name: "Cozy Bed", description: "A soft bed for your pet", category: "decor", cost: 150 },
        { name: "Plant Pot", description: "A cute little plant", category: "decor", cost: 75 },
        { name: "Wall Poster", description: "Brighten up the room", category: "decor", cost: 50 },
        { name: "Lamp", description: "A warm glowing lamp", category: "decor", cost: 100 },
        { name: "Tennis Ball", description: "A fun toy to play with", category: "items", cost: 25 },
        { name: "Squeaky Toy", description: "Makes a fun sound", category: "items", cost: 40 },
        { name: "Frisbee", description: "For outdoor fun", category: "items", cost: 35 },
        { name: "Puzzle Toy", description: "Keeps your pet thinking", category: "items", cost: 60 },
        { name: "Kibble Bag", description: "Tasty pet food", category: "food", cost: 20 },
        { name: "Gourmet Treats", description: "Special occasion snacks", category: "food", cost: 45 },
        { name: "Berry Mix", description: "Healthy fruit treats", category: "food", cost: 30 },
        { name: "Fish Snacks", description: "Omega-3 rich treats", category: "food", cost: 55 },
      ]);

      console.log("Database seeded!");
    }
  }

  return httpServer;
}
