import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useRoomItems() {
  return useQuery({
    queryKey: [api.room.items.path],
    queryFn: async () => {
      const res = await fetch(api.room.items.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch room items");
      return api.room.items.responses[200].parse(await res.json());
    },
  });
}

export function useUpdateRoomItems() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (items: any[]) => {
      const res = await fetch(api.room.update.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update room");
      return api.room.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.room.items.path] });
    },
  });
}

export function useInventory() {
  return useQuery({
    queryKey: [api.inventory.list.path],
    queryFn: async () => {
      const res = await fetch(api.inventory.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch inventory");
      return api.inventory.list.responses[200].parse(await res.json());
    },
  });
}
