import { useAuth } from "@/hooks/use-auth";
import { useCreateStudentProfile, useCreateTeacherProfile } from "@/hooks/use-profile";
import { Button } from "@/components/ui/button";
import { GraduationCap, School } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

export default function Onboarding() {
  const { user } = useAuth();
  const [role, setRole] = useState<'student' | 'teacher' | null>(null);
  const createStudent = useCreateStudentProfile();
  const createTeacher = useCreateTeacherProfile();
  const [, setLocation] = useLocation();

  const handleContinue = async () => {
    try {
      if (role === 'student') {
        await createStudent.mutateAsync({ gradeLevel: 1 });
        setLocation('/dashboard');
      } else if (role === 'teacher') {
        await createTeacher.mutateAsync({ subject: 'General' });
        setLocation('/teacher-dashboard');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const isPending = createStudent.isPending || createTeacher.isPending;

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-display font-bold text-gray-900 mb-4">Welcome, {user?.firstName}!</h1>
          <p className="text-xl text-gray-600">To get started, please tell us who you are.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <button
            type="button"
            className={`text-left rounded-2xl border-2 p-6 shadow-sm transition-all duration-300 bg-white cursor-pointer ${role === 'student' ? 'border-primary ring-4 ring-primary/10 scale-105' : 'border-gray-200 hover:border-gray-300'}`}
            onClick={() => setRole('student')}
            data-testid="button-role-student"
          >
            <div className="flex flex-col items-center text-center">
              <div className="w-24 h-24 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mb-6">
                <GraduationCap className="w-12 h-12" />
              </div>
              <h3 className="text-2xl font-bold font-display text-gray-900 mb-2">I am a Student</h3>
              <p className="text-gray-500">I want to join a classroom, learn, and grow my pet.</p>
            </div>
          </button>

          <button
            type="button"
            className={`text-left rounded-2xl border-2 p-6 shadow-sm transition-all duration-300 bg-white cursor-pointer ${role === 'teacher' ? 'border-secondary ring-4 ring-secondary/10 scale-105' : 'border-gray-200 hover:border-gray-300'}`}
            onClick={() => setRole('teacher')}
            data-testid="button-role-teacher"
          >
            <div className="flex flex-col items-center text-center">
              <div className="w-24 h-24 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 mb-6">
                <School className="w-12 h-12" />
              </div>
              <h3 className="text-2xl font-bold font-display text-gray-900 mb-2">I am a Teacher</h3>
              <p className="text-gray-500">I want to create assignments and manage my classroom.</p>
            </div>
          </button>
        </div>

        <div className="flex justify-center">
          <Button 
            size="lg" 
            className="w-full md:w-auto px-12 rounded-full font-bold text-lg h-14 bg-primary hover:bg-primary/90"
            disabled={!role || isPending}
            onClick={handleContinue}
          >
            {isPending ? "Creating Profile..." : "Continue"}
          </Button>
        </div>
      </div>
    </div>
  );
}
